TBrowser Version 0.99 Beta 3

Installation

Extract the files contained in this zip file to a directory of 
your choice and double click on "TBrowser.exe".

Version History

Version 0.99 Beta 3

Released - 12/03/2001


This software is freeware which means you can do what you like with
it except charge money for the software. A freeware licence also 
means that you use this software at your own risk. 
Copyright �2001, 4thbeach Software Pty Ltd.
