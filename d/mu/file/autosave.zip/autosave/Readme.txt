Hi 

The autosave is added to the tools menu.  From there you can set the 
parameters as needed.

Your

Anton