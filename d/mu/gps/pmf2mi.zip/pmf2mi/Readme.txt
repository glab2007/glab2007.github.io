pmf2mi, cGPSmapper to MapInfo maps converter
Version 1.0 alpha 1
(C) 2002 by Olexa Riznyk (www.olexa.com.ua)


CONTENTS

1. Introduction
2. License agreement
3. Installation
4. Usage
5. Upgrades and feedback


-----------------------------------------------------------------
1. INTRODUCTION
-----------------------------------------------------------------

pmf2mi is a utility for converting maps from cGPSmapper
(http://gps.chrisb.org) converter format (so-called polish map
format) to MapInfo GIS.

pmf2mi does not convert maps from Garmin MapSource� format
directly. You need to export the map to polish map format by
cGPSmapper or GPSMap Edit (http://kgy.narod.ru) first.

pmf2mi is intended for importing maps to MapInfo GIS for further
optimization and later conversion back to Garmin format.


-----------------------------------------------------------------
2. LICENSE AGREEMENT
-----------------------------------------------------------------

This version of pmf2mi is freeware.

Author does not take any responsibilities for the risks
that may be resulted by using or not using pmf2mi.

pmf2mi is a script written in JScript language and
distributed in source code.

You may not change name or copyright notes in pmf2mi.

You may not redistribute pmf2mi, unless its agreed with
author. You may only distribute links to pmf2mi homepage.

You may use pmf2mi code in your programs, however it would
be nice to refer to pmf2mi's author in your copyright notes.


-----------------------------------------------------------------
3. INSTALLATION
-----------------------------------------------------------------

pmf2mi does not require any special installation. Just
unzip pmf2mi.js file to any folder.

Note that your system must be able to run JScript scripts.
In Windows this is assured by installing latest version of
Internet Explorer or Windows Script Host.


-----------------------------------------------------------------
4. USAGE
-----------------------------------------------------------------

pmf2mi must be run when MapInfo is started.

You can see pmf2mi command-line options by running it without any
parameters or with "/?" parameter.

Note that you need to run pmf2mi in command line mode. This may
be done by typing "cscript " (instead of wscript or nothing)
before pmf2mi file name and path, or by running
"cscript //H:CScript" or "wscript //H:CScript" once before
running pmf2mi: this would change default script host to
command-line version (cscript).


-----------------------------------------------------------------
6. UPGRADES AND FEEDBACK
-----------------------------------------------------------------

Note that this is just alpha version. It may contain bugs and may
seem to be (and actually is) unfinished.

pmf2mi homepage is http://www.olexa.com.ua/gps/pmf2mi

Please send bug report, new feature propositions and
feedback to pmf2mi@olexa.com.ua.
