GridWinE creates a grid of squares between a lower left pointing and an upper right pointing. The size of the square is user-specified. 
GridWinE works on Earth maps exactly like GridWin works on NonEarth maps. 

Source code included.