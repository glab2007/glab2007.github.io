PermaTIC

This application allows having "permanent" Lat/Lon [x/y] labels on the map
The labels are along the left side for Lat/Y and top for Lon/X.

Built on a PII-266, 128m, 8m Video, NT4W sp4, MapInfo 4.5, MapBasic 4.0

PermaTIC.INI is a standard Window INI file that you can use to customize 
how the TICS appear such as: 
1) number of TICS, 
2) display decimal degrees D (also for maps in non-lon/lat), or
   decimal minutes DD MM.mm, or 
   decimal seconds DD MM SS.ss,  
4) font name/style/size/foreground/background,
5) display the � ' " (for x/y units m/ft/etc) or just a blank space
6) allow user to can change settings,
7) show on start or wait for user to show,
8) whether the text tics are "flush" with the window or "extend" into the window
9) optionally save user changes back to the INI for the next time.

NOTE: the mbx and ini "must" be in the same folder

To help set the font values and colors do the following:
1) open a map
2) chose Options>Show MapBasic Window
3) chose Map>Layer Control....
4) select the layer
5) click on LABEL...
6) Click on the "Styles" Font Button ( "Aa" icon )
7) Set you text name,size,style....
8) Click OK on each dialog to finish
8) A line in the MapBasic Window will look something like:
   Set Map Layer 3 Label Font ("Arial",256,9,0,16711680)
10) inside the paranthesis (....) is in this order: 
   FontName, FontStyle, FontSize, ForeColor, BackColor
11) Use this for the setting in the INI File

Below is the included "default" (should you destroy it) INI file
which contains comments about each line.  This is a standard Windows INI file.
Use a semi-colon ; to enter comments

===  THE INI FILE ===============================

[SYSTEM]

;NUMBER OF TICS
; number of tics from 1 to 20 [default 5]
Tics=5

;SHOW TICS ON START or wait for user to start
; T => show tics on start up [default]
; F => wait for user to start
AutoStart=F 

;USER CHANGE SETTINGS
; allow user to change setting #tics/font/display [d dms]
; T => True user can change [default]
; F = > False can not change 
UserChange=T

;SHOW FLUSH
; sets whether text is along window edge or extends into the window
; T => Text Flush
; F => Text Extends into window [default]
ShowFlush=F

;DISPLAY MODES
; how the tic text is displayed
; D => decimal degrees 97.1234567� [default mode]
; DM => degree decimal minutes 97� 45.3333'
; DMS => degree minute decimal seconds 97� 45' 22.25"
; X => non-earth as decimal values 1,123,456m
Display=D

;SHOW UNITS
; how the text is displayed  
; for Lon/Lat shows � chr$(167) deg / ' chr$(39) min / " chr$(34) sec
; for X/Y shows MI units text m=meters / mi=miles / ft=feet / etc......
; T => True show units [default]
; F => False do not show units [only a space separator is used]
ShowUnit=T

;TEXT FONT 
; FontName => Must be exact Windows Font Name [ Arial is default ]
; DO NOT PUT ANY QUOTES " AROUND THE NAME
; MUST BE EXACT => Timer New Roman => Arial [including Caps]
FontName=Courier New

;TEXT STYLE
; if the word appears then that style is set [like checking in Font Dialog]
; default is nothing => all styles off => leave blank after =
; USE => PLAin / BOLd / ITAlic / UNDerline / SHAdow / HALo / all CAPs / EXPanded
; the CAPS being all that you must put in with a space between each
; example => Bold UnderLine
FontStyle=UNDerline

;TEXT SIZE
; the font size => must be a valid range => 7 is default
FontSize=7

;TEXT FOREGROUND COLOR
; ForeGround Color
; MUST be the MapInfo numeric code [not BLACK] [0 is default=Black]
ForeColor=0

;TEXT BACKGROUND COLOR
; BackGround Color
; MUST be the MapInfo numeric code [ 16776960 is Yellow = default ]
BackColor=16776960
