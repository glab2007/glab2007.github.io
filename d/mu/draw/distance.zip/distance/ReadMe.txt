
------------------------------------------------------------------------------
Table of contents:

A. KOREM Corporation License Agreement 
B. How to use Distance tool
------------------------------------------------------------------------------

A. KOREM Corporation License Agreement

The software is subject to the terms and conditions detailed in the following license agreement. 

NOTICE:
KOREM licenses the enclosed software to you only upon the condition that you accept all of the terms contained in this license agreement. Before you accept the license please read the terms and conditions of this agreement. If you do not agree to these terms and conditions, then KOREM is unwilling to license the software to you, in which case you should, not use the software and remove the software from your system. By accepting those terms, you are consenting to be bound by and are becoming a party to this agreement.

LICENSE: 
The software which accompanies this license (the "Software") is the property of KOREM or its licensors and is protected by copyright law. While KOREM continues to own the Software, you will have certain limited rights to use the Software after your acceptance of this license. Your rights and obligations with respect to the use of this Software are as follows: 
You may:  
use one copy of the Software on any computer;
copy the documentation which accompanies the Software; 
distribute the Software to other people.
You may not:
reverse engineer, decompose, disassemble, modify, translate, make any attempt to discover the source code of the Software, or create derivative works from the Software.    

NO WARRANTY:
The "Distance" tool is delivered with neither warranty nor service from KOREM.

LIMITATION OF LIABILITY:
To the maximum extent permitted by applicable law, in no event shall KOREM or its suppliers be liable for any special, incidental, indirect, or consequential damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or any other pecuniary loss) arising out or the use of or inability to use this KOREM product or the provision of or failure to provide support services, even if KOREM has been advised of the possibility of such damages.

Should you have any questions concerning this client Access License, or if you desire to contact KOREM for any reason please write to the Customer Services: Le Groupe KOREM inc., 3360, de La P�rade, suite 200, Sainte-Foy, Quebec, Canada G1X 2L7.

------------------------------------------------------------------------------


B. How to use Distance tool

The Distance tool makes it possible to measure the minimal distance, in meters, between the objects of table A and those of table B. The object identification and the measured distance are stored in previously defined fields in table A. 

1- Run the MapBasic application "Distance" in MapInfo (v.4.0+).

2- Open the two tables between which the distances will be measured. Those tables should not be in Longitude/Latitude but rather in a local projection which minimizes distance distortion. 

3- Select the objects from which you want to measure the distances. 

4- Activate the command Distance /Measure distances... 

5- In the dialog box...
  5.1- Check off the box "Distance field" and identify the field in which will be registered the measured distance.
  5.2- Check off the box "Identification field" and identify the field in which will be registered the identification of the nearest object found.
  5.3- Identify the "Reference table", where will be searched the nearest object from each selected object.
  5.4- If you checked off the box "Identification field" for the table of the selected objects, select the field of the reference table that identifies the objects.
  5.5- Specify the initial search radius. Fix it according to the average distance estimated between the selected objects and those of the reference table.
  5.6- Specify the maximum search radius. The application will stop searching if, after this distance, no object was found. 
  5.7- Modify, if necessary, the resolution of created buffers. A too large value will slow down the application. Note that this parameter does not affect the measured distance.
  5.8- Click OK.

------------------------------------------------------------------------------


