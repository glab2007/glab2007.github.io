using System;
using System.Windows;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;

namespace MBExtensions
{
   class MBSearch
	{
		public static Form frmSearch = new Form();
		public static bool frmClosed = false;
		public static String sReturnValue = "", tableName, columnName;
		public static string[] sSearchArray;
		public static ListView lstSelection;
		public static TextBox txtSearch;
		public static Button btnResp = new Button ();
		public static Button btnOK = new Button ();
		public static Button btnCancel = new Button ();
	
		public static String SearchBox(string[] aSearch, string tabName, string colName)
		{
			sSearchArray = aSearch;
			tableName = tabName;
			columnName = colName;
			
			SearchBoxForm();
			
			// keep checking if the dialog is closed (MapBasic is waiting)
			while(!frmClosed)
			{
				Thread.Sleep(300);
			}
			return sReturnValue;
		}
		
		public static void SearchBoxForm()
		{
			frmSearch = new Form();
			frmSearch.MaximizeBox = false;
			frmSearch.MinimizeBox = false;
			frmSearch.ShowInTaskbar = false;
			frmSearch.ShowIcon = false;
			frmSearch.Width = 400;
			frmSearch.Height = 450;
			frmSearch.FormBorderStyle = FormBorderStyle.FixedSingle; 
			frmSearch.Text = "MapSearch";
			Label lblSearch = new Label();
			lblSearch.Text = String.Format("Search table {0} ", tableName);
			lblSearch.Location = new Point(10,10);
			lblSearch.Width = 380;
			Label lblSearch2 = new Label();
			lblSearch2.Text = String.Format("for values in column {0}: ", columnName);
			lblSearch2.Location = new Point(10,35);
			lblSearch2.Width = 270;
			txtSearch = new TextBox();
			txtSearch.Location = new Point(10,65);
			txtSearch.Width = 270;
			txtSearch.TextChanged += new EventHandler(FilterList);
			txtSearch.KeyDown += new KeyEventHandler(enter_KeyDown);
			
			lstSelection = new ListView();
			lstSelection.View =  View.Details;
			lstSelection.Location = new Point(10,95);
			lstSelection.Width = 370;
			lstSelection.Height = 270;
			lstSelection.KeyDown += new KeyEventHandler(enter_KeyDown);
			
			ColumnHeader lvcName = new System.Windows.Forms.ColumnHeader();
			lvcName.Text = columnName;
			lvcName.Width = 250;

			lstSelection.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {lvcName});
            lstSelection.FullRowSelect = true;
            lstSelection.MultiSelect = false;
            lstSelection.Sorting = System.Windows.Forms.SortOrder.Ascending;
			
			
			lstSelection.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(lstSelection_OnColumnClick);
			lstSelection.MouseDoubleClick += new MouseEventHandler(enter_DoubleClick);
			lstSelection.SelectedIndexChanged += new System.EventHandler(lstSelection_OnSelectedIndexChanged);

			addItems();
			
			btnResp.Text = "&Respecify...";
			btnResp.Width = 90;
			btnResp.Location = new Point(290,32);
			btnResp.Click += new System.EventHandler(SearchBoxRespecify);

			btnOK.Text = "&OK";
			btnOK.Width = 60;
			btnOK.Location = new Point(250,380);
			btnOK.Click += new System.EventHandler(SearchBoxOk);

			btnCancel.Text = "&Cancel";
			btnCancel.Width = 60;
			btnCancel.Location = new Point(320,380);
			btnCancel.Click += new System.EventHandler(SearchBoxCancel);
			btnOK.Enabled = false;
			
			frmSearch.Controls.Add(lblSearch);
			frmSearch.Controls.Add(lblSearch2);
			frmSearch.Controls.Add(btnResp);
			frmSearch.Controls.Add(txtSearch);
			frmSearch.Controls.Add(lstSelection);
			frmSearch.Controls.Add(btnOK);
			frmSearch.Controls.Add(btnCancel);
			frmSearch.StartPosition = FormStartPosition.CenterScreen;

			txtSearch.Select();
			frmSearch.ShowDialog();
		}
		
		public static void SearchBoxRespecify(object sender, System.EventArgs e)
		{
			sReturnValue = "Respecify";
			frmClosed = true;
			frmSearch.Close();
		}
		
		public static void SearchBoxOk(object sender, System.EventArgs e)
		{
			frmClosed = true;
			frmSearch.Close();
		}
		
		public static void SearchBoxCancel(object sender, System.EventArgs e)
		{
			sReturnValue = "";
			frmClosed = true;
			frmSearch.Close();
		}

		public static void FilterList(object sender, System.EventArgs e)
		{
			addItems();
		}
		
		private static void enter_KeyDown(object sender, KeyEventArgs e)
		{
			 if (e.KeyCode == Keys.Enter  & 
				btnOK.Enabled)
			 {
				 btnOK.PerformClick();
			 }
		}
		
		private static void enter_DoubleClick(object sender, MouseEventArgs e)
		{
			 if (btnOK.Enabled)
			 {
				 btnOK.PerformClick();
			 }
		}
		
		/**********
		*  Put all items from the arrays in the listview, as long as the contain the string in txtSearch
		*********/
        public static void addItems()
        {
			lstSelection.Items.Clear();
			btnOK.Enabled = false;
			sReturnValue = "";

			foreach(string elem in sSearchArray)
			{
				if (elem.ToUpper().Contains(txtSearch.Text.ToUpper()))
				{
					lstSelection.Items.Add(new ListViewItem(new string[]{elem}));
				}
			}
			
			if (lstSelection.Items.Count == 1)
			{
				lstSelection.Items[0].Selected = true;
			}
		}
		
		/**********
		*  Save selected item
		*********/
		private static void lstSelection_OnSelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (lstSelection.SelectedItems.Count == 0)
            {
				btnOK.Enabled = false;
				sReturnValue = "";
                return;
            }
			else
			{
				btnOK.Enabled = true;
				sReturnValue = lstSelection.SelectedItems[0].SubItems[0].Text;
				return;
			}
        }
		
		/**********
		*  Sort columns
		*********/
		private static void lstSelection_OnColumnClick(object sender, System.Windows.Forms.ColumnClickEventArgs e)
        {
            ListViewSorter Sorter = new ListViewSorter();
            lstSelection.ListViewItemSorter = Sorter;
            if (!(lstSelection.ListViewItemSorter is ListViewSorter))
                return;
            Sorter = (ListViewSorter) lstSelection.ListViewItemSorter;

            if (Sorter.LastSort == e.Column)
            {
                if (lstSelection.Sorting == SortOrder.Ascending)
                    lstSelection.Sorting = SortOrder.Descending;
                else
                    lstSelection.Sorting = SortOrder.Ascending;
            }
            else{
                lstSelection.Sorting = SortOrder.Descending;
            }
            Sorter.ByColumn = e.Column;

            lstSelection.Sort ();
        }
	}
	
	public class ListViewSorter : System.Collections.IComparer
    {
        public int Compare (object o1, object o2)
        {
            if (!(o1 is ListViewItem))
                return (0);
            if (!(o2 is ListViewItem))
                return (0);

            ListViewItem lvi1 = (ListViewItem) o2;
            string str1 = lvi1.SubItems[ByColumn].Text;
            ListViewItem lvi2 = (ListViewItem) o1;
            string str2 = lvi2.SubItems[ByColumn].Text;

            int result;
            if (lvi1.ListView.Sorting == SortOrder.Ascending)
                result = String.Compare (str1, str2);
            else
                result = String.Compare (str2, str1);

            LastSort = ByColumn;

            return (result);
        }


        public int ByColumn
        {
            get {return Column;}
            set {Column = value;}
        }
        int Column = 0;

        public int LastSort
        {
            get {return LastColumn;}
            set {LastColumn = value;}
        }
        int LastColumn = 0;
    }   
}
