﻿**********************
***   GeoAS Help   ***
**********************

Das Program kann mit folgenden Parametern ausgeführt werden:

 -config [ConfigName]
 -version [Version]
 -topicid [TopicID]
 -debug

Beispiel:
  GeoASHelp.exe -Config GeoAS_Management -TopicID 1002 -Version 700 -debug
