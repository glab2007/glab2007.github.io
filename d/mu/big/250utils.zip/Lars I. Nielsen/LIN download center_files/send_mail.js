function send_mail (id) {
	var w = open("/php/sendamail.php?id=" + id, "mail","width=30,height=10");
	if (!w) alert('Der anvendes et popup-vindue/Using popup windows')
}