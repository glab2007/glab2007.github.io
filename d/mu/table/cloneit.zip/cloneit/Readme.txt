Program:   	CloneIt.mbx
Version:	1.0
For:        	Mapinfo 4.1 for Windows 3.1/95/NT
By:         	James Marlow (jmarlow@uswavelink.com or vaxcrshr@onramp.net)
Created:    	19 July, 1997
Copyright:  	Copyright 1997 Maps Unlimited

CloneIt is a MapBasic program that creates a new table based on the structure
of either an existing table or a stored profile.  The program adds a menu 
item ot the File Menu (Clone Table...) and a button to the Tools buttonpad.
You can define a hot-key combination for the program although the default
is no hot key.  The new table format will exactly match the source table or
profile, including Map, Projection and Index settings.

Selecting File|Clone Table will bring up the Clone Table dialog box which
contains the following controls:
	- "New Table Name" - enter the name of the table you wish to create
	  here.  You can type in the name or click the Browse button to the
	  right of the text box to enter a path/name combination using the
	  standard Windows Save dialog box.

	- "Table Format Source" Options - you can select either "Mapinfo
	  Table" or "Stored Profile".  If you select "Mapinfo Table" then
	  the text box below this option is enabled and you can either enter
	  a table name or click the browse button to select a table.  If you
	  select "Stored Profile" the list below the Source Table text box
	  is enabled and you can select a stored profile to use in creating
	  a new table.  

	- "Source Table For Structure" Text Box - If you selected "Mapinfo
	  Table" as your Table Format Source (see above) then you can enter
	  a source table in this box or click the browse button to select
	  the table.  When you click the Create button the new table will
	  be created using the format of the table entered here.

	- "Source Profile For Structure" List - If you selected "Stored
	  Profile" as your Table Format Source (see above) then you can
	  select a stored profile from this list.  The new table will be
	  created using this stored profile when you click the Create
	  button.  If you want to modify the contents of this list you can
	  do so using the Add and Delete buttons to the right of the list.

	- "Add" Button - If you selected "Stored Profile" as your Table
	  Format Source" (see above) then you can click this button to add
	  a new profile to the list.  When you do this you will be prompted
	  for a profile name and a table to copy the profile from.  This
	  might seem a bit redundant, but who wants to go wading through
	  directories every time a new table needs to be created?

	- "Delete" Button - If you selected "Stored Pofile" as your Table
	  Format Source" (see above) then you can click this button to
	  delete the selected profile from the profile list.  You will be
	  asked if you really want to do this, but you don't have to provide
	  a note from your mother.

	- "Settings" Button - This displays the Settings dialog in which you
	  can turn on and off the Autoload feature (On - CloneIt loads when
	  Mapinfo does) and set the Hot Key combination.  Clicking Ok in this
	  dialog saves the settings and makes the changes immedeatly.

	- "About" Button - Displays the usual About dialog containing information
	  about the author (me), version and the obligatory copyright statement.

	- "Unload" Button - Unloads CloneIt from memory.

	- "Create" Button - Creates a new table using the current settings. Note
	  that this does NOT close the dialog box - maybe you wanted to create
	  more than one table.   The new table will be opened and displayed in
	  a browser (future versions might add to this).

	- "Close" Button - Closes the Clone Table dialog box, but does not unload
	  the program from memory.

To install unzip the file and copy its contents to a directory and then run
CloneIt.mbx.  Select File|Clone Table used files to create new tables, change
CloneIt program settings or to unload the program.

WARNING:  This program is provided "As Is" and no warranty or representation is
made as to the lack of bugs or the results this program will provide.  USE AT
YOUR OWN RISK!

Having said that, if you do have a problem with this program, please feel free to
contact me at the e-mail addresses above.  I generally tend to fix any bugs I find,
or at least provide an explanation/workaround.

James Marlow
19 July, 1997