//---------------------------------------------------------------------------

#ifndef WindowDividerH
#define WindowDividerH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
//---------------------------------------------------------------------------
class PACKAGE TWindowDivider : public TLabel
{
typedef inherited TLabel;
static const unsigned char BorderWeight = 2;
private:
protected:
	DYNAMIC void __fastcall DoDrawText(Types::TRect &Rect, int Flags);
	DYNAMIC void __fastcall AdjustBounds(void);
public:
	__fastcall TWindowDivider(TComponent* Owner);
__published:
};
//---------------------------------------------------------------------------
#endif
