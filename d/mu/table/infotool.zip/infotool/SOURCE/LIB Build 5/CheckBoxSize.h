//---------------------------------------------------------------------------

#ifndef CheckBoxSizeH
#define CheckBoxSizeH
//---------------------------------------------------------------------------
#define OBM_CHECKBOXES      32759
struct TCheckBoxSize
{
short Width;
short Height;
TCheckBoxSize();
};


extern TCheckBoxSize DefaultCheckBoxSize;



#endif
 