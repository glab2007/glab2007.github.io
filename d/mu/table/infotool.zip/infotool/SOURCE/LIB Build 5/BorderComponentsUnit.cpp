#include <vcl.h>
#pragma hdrstop

#include "BorderComponentsUnit.h"
#include "CheckBoxSize.h"

//#pragma package(smart_init)

const TColor DefaultColor = 0x00B99D7F;

inline void DrawCheckBoxBorder(TBorderCheckBox * WinControl, TColor BorderColor, TColor Color)
{
//������� ����������� ����� checkbox'�
	HBRUSH Brush = CreateSolidBrush(BorderColor);
	TRect R;
	short siOffsetX, siOffsetY;
	HDC DC = GetWindowDC(WinControl->Handle);

	if (WinControl->Alignment == taLeftJustify)
		siOffsetX = WinControl->Width - DefaultCheckBoxSize.Width;
	else
		siOffsetX = 0;
	siOffsetY = (WinControl->Height - DefaultCheckBoxSize.Height) / 2;
	R.Top = siOffsetY;
	R.Bottom = R.Top + DefaultCheckBoxSize.Height;
	R.Left = siOffsetX;
	R.Right = R.Left + DefaultCheckBoxSize.Width;
	FrameRect(DC , &R , Brush);
	DeleteObject(Brush);

	if ((Color >= clScrollBar) && (Color <= clMenuBar))
		Color = (TColor)GetSysColor(Color - clScrollBar);
	Brush = CreateSolidBrush(Color );
	R = Rect(R.Left + 1 , R.Top + 1 , R.Right - 1 , R.Bottom - 1);
	FrameRect(DC , &R , Brush);
	ReleaseDC(WinControl->Handle,DC);
	DeleteObject(Brush);
}

inline void DrawControlBorder(TWinControl * WinControl, TColor BorderColor, TColor Color)
{
//������� ����������� ����� ��������� (����� checkbox)
	HDC DC = GetWindowDC(WinControl->Handle);
	RECT R, CR;
	HBRUSH BorderBrush = CreateSolidBrush(BorderColor);

	try
	{
		GetWindowRect(WinControl->Handle,&R);
		GetClientRect(WinControl->Handle,&CR);

		OffsetRect(&R , -R.left , -R.top);
		FrameRect(DC , &R , BorderBrush);
		DeleteObject(BorderBrush);

			if (!EqualRect(&R,&CR))
			{
				OffsetRect(&CR , (((R.right-R.left)-(CR.right-CR.left))/2) , (((R.bottom-R.top)-(CR.bottom-CR.top))/2));
				ExcludeClipRect(DC, CR.left, CR.top, CR.right, CR.bottom);
				InflateRect(&R, -1, -1);
				FillRect(DC, &R, WinControl->Brush->Handle);
			}
			else
			{
				InflateRect(&R, -1, -1);
				FrameRect(DC , &R , WinControl->Brush->Handle);
			}
		ReleaseDC(WinControl->Handle , DC);
	}
	catch(...)
	{
		DeleteObject(BorderBrush);
		ReleaseDC(WinControl->Handle , DC);
		throw;
	}
}


inline bool __fastcall NewLabelPosition(TBorderBoundLabel * EditLabel,TWinControl * Control,TLabelPosition const& Value,int LabelSpacing)
{
//�������, ���������� ��������� ������� ������������ ��������
	TPoint P;

	if(EditLabel == NULL)
		return false;
	switch(Value)
	{
	case lpAbove:
		{
			P =Point(Control->Left , Control->Top - EditLabel->Height - LabelSpacing);
			EditLabel->Alignment =taCenter;
			break;
		}
	case lpBelow:
		{
			P =Point(Control->Left , Control->Top + Control->Height + LabelSpacing);
			EditLabel->Alignment =taCenter;
			break;
		}
	case lpLeft:
		{
			P =Point(Control->Left-(EditLabel->Width)-LabelSpacing, Control->Top+((Control->Height-(EditLabel->Height)) / 2));
			EditLabel->Alignment =taRightJustify;
			break;
		}
	case lpRight:
		{
			P =Point(Control->Left + Control->Width + LabelSpacing,Control->Top + ((Control->Height - EditLabel->Height) / 2));
			EditLabel->Alignment =taLeftJustify;
			break;
		}
	}
	EditLabel->SetBounds(P.x , P.y , EditLabel->Width , EditLabel->Height);
	return true;
}

/* TBorderBoundLabel */
__fastcall TBorderBoundLabel::TBorderBoundLabel(Classes::TComponent* AOwner): inherited(AOwner)
{
	this->TabStop = false;
	Name = "SubLabel";
	SetSubComponent(true);
		if(AOwner)
		Caption = AOwner->Name;
}

void __fastcall TBorderBoundLabel::CreateParams(Controls::TCreateParams &Params)
{
	inherited:: CreateParams(Params);
	Params.Style = Params.Style | SS_CENTERIMAGE;
}

void __fastcall TBorderBoundLabel::CMTextChanged(TMessage & Message)
{
	inherited::Dispatch(&Message);
	Invalidate();
	AdjustBounds();
}

void TBorderBoundLabel::AdjustBounds()
{
	HDC DC;
	HFONT SaveFont;
	TSize TextSize;

	if(!(ComponentState.Contains(csReading)) && AutoSize)
	{
		DC = GetDC(0);
		SaveFont = SelectObject(DC , Font->Handle);
		GetTextExtentPoint32(DC , Caption.c_str() , Caption.Length() , &TextSize);
		SelectObject(DC , SaveFont);
		ReleaseDC(0 , DC);
		SetBounds(Left , Top
						, TextSize.cx + (GetSystemMetrics(SM_CXBORDER) * 4)
						, TextSize.cy + (GetSystemMetrics(SM_CYBORDER) * 4));
	}
	TBorderEdit* OwnerEdit = dynamic_cast<TBorderEdit*>(Owner);

	if (OwnerEdit)
	OwnerEdit->UpdateLabelPosition();
	else
	{
		TBorderComboBox* OwnerEdit = dynamic_cast<TBorderComboBox*>(Owner);

		if (OwnerEdit)
			OwnerEdit->UpdateLabelPosition();
		else
		{
			TBorderDateEdit* OwnerEdit = dynamic_cast<TBorderDateEdit*>(Owner);
			if (OwnerEdit)
				OwnerEdit->UpdateLabelPosition();
		}
	}
}
/* TBorderEdit */

__fastcall TBorderEdit::TBorderEdit(Classes::TComponent* AOwner): inherited(AOwner)
{
	FLabelPosition = lpLeft;
	FLabelSpacing = 3;
	SetupInternalLabel();
	ControlStyle << csClickEvents << csSetCaption << csDoubleClicks << csFixedHeight << csOpaque;
	FBorderColor = static_cast<TColor>(0x00B99D7F);
	TBorderEdit::Color = clWindow;
}

void __fastcall TBorderEdit::EraseBorder(TMessage & Message)
//������� ������������ ����������� �����
{
//inherited::Dispatch(&Message);
	DrawControlBorder(this , FBorderColor , Color);
}


void TBorderEdit::SetupInternalLabel()
{
	if(FEditLabel)
		return;
	FEditLabel = new TBorderBoundLabel(this);
	FEditLabel->FreeNotification(this);
	FEditLabel->FocusControl = this;
}

void __fastcall TBorderEdit::SetName(const AnsiString Value)
{
	if((ComponentState.Contains(csDesigning)) && ((FEditLabel->GetTextLen() == 0) || (CompareText(FEditLabel->Caption, Name) == 0)))
		FEditLabel->Caption = Value;
	inherited:: SetName(Value);

	if(ComponentState.Contains(csDesigning))
		Text = "";
}

void __fastcall TBorderEdit::CMEnabledChanged(Messages::TMessage & Message)
//������� ������������ ����������� �������
{
	inherited::Dispatch(&Message);
	FEditLabel->Enabled = Enabled;
}

void __fastcall TBorderEdit::CMVisibleChanged(TMessage & Message)
//������� ������������ ��������� �������
{
	inherited::Dispatch(&Message);
	FEditLabel->Visible = Visible;
}

void __fastcall TBorderEdit::CMBiDiModeChanged(TMessage & Message)
{
	inherited::Dispatch(&Message);
	FEditLabel->BiDiMode = BiDiMode;
}

void __fastcall TBorderEdit::Notification(Classes::TComponent* AComponent, Classes::TOperation Operation)
{
	inherited:: Notification(AComponent , Operation);
	if((AComponent == FEditLabel) && (Operation == opRemove))
		FEditLabel = NULL;
}

void __fastcall TBorderEdit::SetBounds(int ALeft, int ATop, int AWidth, int AHeight)
{
	inherited:: SetBounds(ALeft , ATop , AWidth , AHeight);
	SetLabelPosition(FLabelPosition);
}

void TBorderEdit::UpdateLabelPosition()
{
	SetLabelPosition(FLabelPosition);
}

void __fastcall TBorderEdit::SetParent(TWinControl* AParent)
{
	inherited:: SetParent(AParent);

	if(FEditLabel == NULL)
		return;
	FEditLabel->Parent = AParent;
	FEditLabel->Visible = true;
}

void __fastcall TBorderEdit::SetLabelPosition(TLabelPosition const& Value)
{
	if (NewLabelPosition(FEditLabel,this,Value,FLabelSpacing));
		FLabelPosition = Value;
}

void __fastcall TBorderEdit::SetLabelSpacing(int const& Value)
{
	FLabelSpacing = Value;
	SetLabelPosition(FLabelPosition);
}

/* TBorderCheckBox */
__fastcall TBorderCheckBox::TBorderCheckBox(Classes::TComponent* AOwner): inherited(AOwner)
{
	ControlStyle >> csOpaque;
	BorderColor = DefaultColor;
}

void __fastcall TBorderCheckBox::CreateWnd(void)
{
	inherited::CreateWnd();
	bool OldReadOnly = FReadOnly;

	if (FReadOnly)
		FReadOnly  = false;
	SendMessage(Handle, BM_SETCHECK, State, 0);
	FReadOnly = OldReadOnly;
}

void __fastcall TBorderCheckBox::EraseCheckBox(TMessage & Message)
{
	inherited::Dispatch(&Message);
	DrawCheckBoxBorder(this , FBorderColor , Color);
}

void __fastcall TBorderCheckBox::SetCheck(TMessage & Message)
{
	if (!FReadOnly)
		inherited::Dispatch(&Message);
	DrawCheckBoxBorder(this , FBorderColor , Color);
}

/* TBorderDateEdit */

__fastcall TBorderDateEdit::TBorderDateEdit(Classes::TComponent* AOwner): inherited(AOwner)
{
	FLabelPosition = lpLeft;
	FLabelSpacing = 3;
	SetupInternalLabel();
	ControlStyle << csClickEvents << csSetCaption << csDoubleClicks << csFixedHeight << csOpaque;
	Ctl3D = false;
	BorderWidth = 0;
	FBorderColor = static_cast<TColor>(0x00B99D7F);
}

void __fastcall TBorderDateEdit::WndProc(Messages::TMessage &Message)
{
	switch(Message.Msg)
	{
	case WM_KEYDOWN:
		{
			if(ReadOnly)
			{
				if(! ((Message.WParam==VK_LEFT) || (Message.WParam==VK_RIGHT)))
				Message.WParam =0;
			}
			else
				FIsTouched = true;
			break;
		}
	case WM_CHAR:
		{
			Message.WParam =0;
			break;
		}
	}
	inherited:: WndProc(Message);
}

void TBorderDateEdit::SetupInternalLabel()
{
	if(FEditLabel)
		return;
	FEditLabel = new TBorderBoundLabel(this);
	FEditLabel->FreeNotification(this);
	FEditLabel->FocusControl = this;
}

void __fastcall TBorderDateEdit::SetName(const AnsiString Value)
{
	if((ComponentState.Contains(csDesigning)) && ((FEditLabel->GetTextLen() == 0) || (CompareText(FEditLabel->Caption, Name) == 0)))
		FEditLabel->Caption = Value;
	inherited:: SetName(Value);
	if(ComponentState.Contains(csDesigning))
		Text = "";
}

void __fastcall TBorderDateEdit::CNNotify(TWMNotify &Message)
{
	inherited::Dispatch(&Message);
	Message.Result = 0;

	switch(Message.NMHdr->code)
	{
		case DTN_DROPDOWN:
		{
			if(ReadOnly)
				EnableWindow(DateTime_GetMonthCal(this->Handle) , false);
			break;
		}
		case DTN_DATETIMECHANGE:
		{
			FIsTouched = true;
			break;
		}
	}
}

void __fastcall TBorderDateEdit::EraseBorder(TMessage & Message)
{
	inherited::Dispatch(&Message);
	DrawControlBorder(this , FBorderColor , Color);
}

void __fastcall TBorderDateEdit::CMVisibleChanged(TMessage & Message)
{
	inherited::Dispatch(&Message);
	FEditLabel->Visible = Visible;
}

void __fastcall TBorderDateEdit::CMBiDiModeChanged(TMessage & Message)
{
	inherited::Dispatch(&Message);
	FEditLabel->BiDiMode = BiDiMode;
}

void __fastcall TBorderDateEdit::CMEnabledChanged(Messages::TMessage & Message)
//������� ������������ ����������� �������
{
	inherited::Dispatch(&Message);
	FEditLabel->Enabled = Enabled;
}

void __fastcall TBorderDateEdit::Notification(Classes::TComponent* AComponent, Classes::TOperation Operation)
{
	inherited:: Notification(AComponent , Operation);
	if((AComponent == FEditLabel) && (Operation == opRemove))
		FEditLabel = NULL;
}

void __fastcall TBorderDateEdit::SetBounds(int ALeft, int ATop, int AWidth, int AHeight)
{
	inherited:: SetBounds(ALeft , ATop , AWidth , AHeight);
	SetLabelPosition(FLabelPosition);
}

void TBorderDateEdit::UpdateLabelPosition()
{
	this->SetLabelPosition(FLabelPosition);
}

void __fastcall TBorderDateEdit::SetParent(TWinControl* AParent)
{
	inherited:: SetParent(AParent);
	if(FEditLabel == NULL)
		return;
	FEditLabel->Parent = AParent;
	FEditLabel->Visible = true;
}

void __fastcall TBorderDateEdit::SetLabelPosition(TLabelPosition const& Value)
{
	if (NewLabelPosition(FEditLabel,this,Value,FLabelSpacing));
		FLabelPosition = Value;
}

void __fastcall TBorderDateEdit::SetLabelSpacing(int const& Value)
{
	FLabelSpacing = Value;
	SetLabelPosition(FLabelPosition);
}


/* TBorderComboBox */

__fastcall TBorderComboBox::TBorderComboBox(Classes::TComponent* AOwner): inherited(AOwner)
{
	FLabelPosition = lpLeft;
	FLabelSpacing = 3;
	SetupInternalLabel();
	ControlStyle << csClickEvents << csSetCaption << csDoubleClicks << csFixedHeight << csOpaque;
	BorderWidth = 0;
	FBorderColor = static_cast<TColor>(0x00B99D7F);
	AutoComplete = true;
	AutoDropDown = false;
	this->OnSelect = SelectValue;
}

void TBorderComboBox::UpdateLabelPosition()
{
	this->SetLabelPosition(FLabelPosition);
}

void TBorderComboBox::SetupInternalLabel()
{
	if(FEditLabel)
		return;
	FEditLabel = new TBorderBoundLabel(this);
	FEditLabel->FreeNotification(this);
	FEditLabel->FocusControl = this;
}

void __fastcall TBorderComboBox::SetName(const AnsiString Value)
{
	if((ComponentState.Contains(csDesigning)) && ((FEditLabel->GetTextLen() == 0) || (CompareText(FEditLabel->Caption, Name) == 0)))
		FEditLabel->Caption = Value;
	inherited:: SetName(Value);
	if(ComponentState.Contains(csDesigning))
		Text = "";
}

void __fastcall TBorderComboBox::CMEnabledChanged(Messages::TMessage & Message)
{
	inherited::Dispatch(&Message);
	FEditLabel->Enabled = Enabled;
}

void __fastcall TBorderComboBox::EraseBorder(TMessage & Message)
{
	inherited::Dispatch(&Message);
	DrawControlBorder(this ,FBorderColor, Color);
}

void __fastcall TBorderComboBox::CMVisibleChanged(TMessage & Message)
{
	inherited::Dispatch(&Message);
	FEditLabel->Visible = Visible;
}


void __fastcall TBorderComboBox::CBShowDropDown(TMessage & Message)
{
	int CurItemIndex = ItemIndex;
	inherited::Dispatch(&Message);
	if (Message.WParam == false)
	{
//		MessageBox(0,"CBShowDropDown",AnsiString(IntToStr(ItemIndex)+" , "+IntToStr(CurItemIndex)).c_str(),0);
		ItemIndex = CurItemIndex;
	}
}

void __fastcall TBorderComboBox::Notification(Classes::TComponent* AComponent, Classes::TOperation Operation)
{
	inherited:: Notification(AComponent , Operation);
	if((AComponent == FEditLabel) && (Operation == opRemove))
		FEditLabel = NULL;
}

void __fastcall TBorderComboBox::SetBounds(int ALeft, int ATop, int AWidth, int AHeight)
{
	inherited:: SetBounds(ALeft , ATop , AWidth , AHeight);
	SetLabelPosition(FLabelPosition);
}

void __fastcall TBorderComboBox::CMBiDiModeChanged(TMessage & Message)
{
	inherited::Dispatch(&Message);
	FEditLabel->BiDiMode = BiDiMode;
}

void __fastcall TBorderComboBox::SetParent(TWinControl* AParent)
{
	inherited:: SetParent(AParent);
	if(FEditLabel == NULL)
		return;
	FEditLabel->Parent = AParent;
	FEditLabel->Visible = true;
}

void __fastcall TBorderComboBox::SetLabelPosition(TLabelPosition const& Value)
{
	if (NewLabelPosition(FEditLabel,this,Value,FLabelSpacing));
		FLabelPosition = Value;
}

void __fastcall TBorderComboBox::SetLabelSpacing(int const& Value)
{
	FLabelSpacing = Value;
	SetLabelPosition(FLabelPosition);
}

void __fastcall TBorderComboBox::SelectValue(System::TObject* Sender)
{
	if (!FReadOnly)
		FDefaultValue = Items->Strings[ItemIndex];
}

void __fastcall TBorderComboBox::WMLButtonUp(TMessage & Message)
{
	inherited::Dispatch(&Message);
//	if (Message.LParam <= -1 && FReadOnly)
//MessageBox(0,"WMLButtonUp","",0);
	Text = FDefaultValue;
}

void __fastcall TBorderComboBox::CMExit(TMessage & Message)
{
//	if (FReadOnly)
	Text = FDefaultValue;
}



