//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "EnterExpressionWindowUnit.h"
//---------------------------------------------------------------------------
//#pragma package(smart_init)
#pragma resource "*.dfm"
TEnterExpressionWindow *EnterExpressionWindow;
//---------------------------------------------------------------------------
__fastcall TEnterExpressionWindow::TEnterExpressionWindow(TComponent* Owner)
		: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TEnterExpressionWindow::AllKeyPress(TObject *Sender,
		char &Key)
{
	switch (Key)
	{
		case Char(VK_TAB): Key = NULL;
			break;
	}
}
//---------------------------------------------------------------------------
void __fastcall TEnterExpressionWindow::CancelButtonClick(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------


