/*********************************************************/
/*                                                       */
/*          ������ InfoToolParametersUnit                */
/*   ������ �������� ������� � ����������, ������������  */
/*   � ��������� InfoTool + � ����������� ��� ���������� */
/*   ���������� �������������� �����                     */
/*                                                       */
/*  Copyright (c) 2005-2006 �������� ���������           */
/*            buls@land.ru                               */
/*                                                       */
/*  �������������: 3.07.2006                             */
/*                                                       */
/*********************************************************/
#pragma once
#ifndef INCLUDED_INFOTOOLPARAMETERSUNIT_H
#define INCLUDED_INFOTOOLPARAMETERSUNIT_H
#include <windows.h>
#include <vcl.h>
#include <vector>
#include <limits>
#include <stdlib>
#include "BulsDdeErrorsUnit.h"
#include "BulsMapInfoConstUnit.h"
#include "BulsMapInfoUtilsUnit.h"
#include "BorderComponentsUnit.h"

using namespace std;

class TInfoToolComboBox: public TBorderComboBox
{
	typedef TBorderComboBox inherited;

public:

	class TBoundLabel: public TBorderBoundLabel
	{
		typedef TBorderBoundLabel inherited;
	private:

		void __fastcall CMMouseEnter( TMessage & Message)/* MESSAGE CM_MOUSEENTER */;
		void __fastcall CMMouseLeave( TMessage & Message)/* MESSAGE CM_MOUSELEAVE */;

		BEGIN_MESSAGE_MAP
		MESSAGE_HANDLER(CM_MOUSEENTER, TMessage, CMMouseEnter)
		MESSAGE_HANDLER(CM_MOUSELEAVE, TMessage, CMMouseLeave)
		END_MESSAGE_MAP(inherited)

	public:
		bool SelectNewTableRow;
		__fastcall TBoundLabel(Classes::TComponent* AOwner): inherited(AOwner),SelectNewTableRow(false)
		{
		Name = "TableRowSubLabel";
		};
	};

public:
	__fastcall TInfoToolComboBox(Classes::TComponent* AOwner);
	TCaption SavedValue;
	unsigned char ValueType;

	AnsiString SourceTable;
	AnsiString ExpressionIdentifier;
	AnsiString ExpressionValue;
	AnsiString ExpressionViewedValue;
	AnsiString AdditionalCondition;
	AnsiString CurrentValuesQuery;
};

class TInfoToolIntEdit: public TBorderEdit
{
	typedef TBorderEdit inherited;
private:
	int FMinValue,FMaxValue;
	void __fastcall WMPaste(TMessage & Message);
	void __fastcall WMCorrectValueOnMessage(TMessage & Message);
	void __fastcall WMChar(TWMKey &Message);
protected:
	bool IsNegativeCurrentValue(AnsiString & Value);//������� ��������� ������� ����� �����
	int DeleteFirstNulls(AnsiString & Value);//������� ������� ������ ���� ������ ����� ��������
	void DeleteNoDigitSymbols(AnsiString & Value);//������� ������� ����������� �������
	virtual int InsertChar(AnsiString & Value,const char NewChar,int StartPosition,int FinishPosition);//������� ������� �������� �-� StartPosition � FinishPosition, � �� �� ����� ��������� ����� ������ NewChar
	virtual bool ToCheckValue(AnsiString & Value);//������� ��������� �� ������������ ������� � ���� ��������
	BEGIN_MESSAGE_MAP
	MESSAGE_HANDLER(WM_PASTE, TMessage, WMCorrectValueOnMessage)
	MESSAGE_HANDLER(CM_EXIT, TMessage, WMCorrectValueOnMessage)
	MESSAGE_HANDLER(WM_CHAR, TWMKey, WMChar)
	END_MESSAGE_MAP(inherited)
public:
	virtual void ToCorrectValue(AnsiString & Value);//������� ��������� �� ������������ ������� � ���� ��������
	__fastcall TInfoToolIntEdit(Classes::TComponent* AOwner,int NewMinValue = INT_MIN,int NewMaxValue = INT_MAX);
};

class TInfoToolFloatEdit: public TInfoToolIntEdit
{
	typedef TInfoToolIntEdit inherited;
protected:
	static const int FDefaultDigitsWidth = 18;
	static const double FDefaultMaxValue;
	static const double FDefaultMinValue;
	static const int FDigitsWidth = FDefaultDigitsWidth;
	double FMinValue, FMaxValue;
	int DecimalSeparatorPosition(AnsiString & Value);
	int GetCurrentValueWidth(AnsiString & Value);//������� ���������� ����� ������� ��������

	bool IsNullCurrentValue(AnsiString & Value);
	int DeleteFirstNulls(AnsiString & Value);
	int DeleteLastNulls(AnsiString & Value);
	void DeleteNoDigitSymbols(AnsiString & Value);
	virtual bool IsCorrectCharCountCurrentValue(AnsiString & Value);
	virtual int InsertChar(AnsiString & Value,const char NewChar,int StartPosition,int FinishPosition);
	virtual bool ToCheckValue(AnsiString & Value);
public:
	virtual void ToCorrectValue(AnsiString & Value);
	__fastcall TInfoToolFloatEdit(Classes::TComponent* AOwner,double NewMinValue = FDefaultMinValue,double NewMaxValue = FDefaultMaxValue);
};

const double TInfoToolFloatEdit::FDefaultMaxValue = 9999999999999999.9;
const double TInfoToolFloatEdit::FDefaultMinValue = (-TInfoToolFloatEdit::FDefaultMaxValue)+1;


class TInfoToolDecimalEdit: public TInfoToolFloatEdit
{
	typedef TInfoToolFloatEdit inherited;
protected:
	static const int FDefaultDigitsWidth = 20;
	static const int FDefaultMaxDecimalsWidth = 16;
	static const double FDefaultMaxValue;
	static const double FDefaultMinValue;
	int FDigitsWidth,FDecimalsWidth;

	int GetCurrentValueWidth(AnsiString & Value);//������� ���������� ����� ������� ��������
	virtual bool IsCorrectCharCountCurrentValue(AnsiString & Value);
	virtual int InsertChar(AnsiString & Value,const char NewChar,int StartPosition,int FinishPosition);
//	virtual bool ToCheckValue(AnsiString & Value);
public:
	virtual void ToCorrectValue(AnsiString & Value);
__fastcall TInfoToolDecimalEdit(Classes::TComponent* AOwner,int NewWidth = FDefaultDigitsWidth, int NewDecplaces = 9,double NewMinValue = FDefaultMinValue,double NewMaxValue = FDefaultMaxValue);
};

const double TInfoToolDecimalEdit::FDefaultMaxValue = 99999999999999999999.9;
const double TInfoToolDecimalEdit::FDefaultMinValue = (-TInfoToolDecimalEdit::FDefaultMaxValue)+1;


struct TListValue
{
	AnsiString sViewedValue;
	AnsiString sSavedValue;
};

typedef std::vector<TListValue> TListValues;

class TViewLine
{
private:
	bool DeleteWorkControl;
public:
	AnsiString sLineName;
	AnsiString sColumnName;
	AnsiString sExpression;
	AnsiString sValue;
	AnsiString sExpressionIdentifier;
	AnsiString sExpressionValue;
	AnsiString sExpressionViewedValue;
	AnsiString sListTable;
	AnsiString sAdditionalCondition;
	AnsiString sCustomDateFormat;
	TListValues ListValues;
	bool bColumnEditable;
	bool bCaptionViewed;
	short siColumnNumber;
	char cViewType;
    unsigned char ucJustify;
	unsigned char ucColumnType;
	unsigned char ucDateFormat;
	unsigned char ValueWidth, ValueDecimals;
	TControl * WorkControl;

void clear()
    {
	sLineName = sColumnName = sExpression = sValue
    = sExpressionIdentifier = sExpressionValue = sListTable
    = sAdditionalCondition= sCustomDateFormat = "";

	ListValues.clear();
	bCaptionViewed = bColumnEditable = false;
	siColumnNumber = 0;
	cViewType = 0;
    ucColumnType = 0;
	ucDateFormat = 0;
	ValueWidth = 0;
	ValueDecimals = 0;
		try
		{
			if (DeleteWorkControl && (WorkControl != NULL))
				WorkControl->Free();
		WorkControl = NULL;
		}
		catch(...)
		{
		WorkControl = NULL;
		}
	}
TViewLine(): DeleteWorkControl(true),sLineName(""),sColumnName(""),sExpression(""),sValue(""),sExpressionIdentifier(""),sExpressionValue(""),
			sListTable(""),sAdditionalCondition(""),sCustomDateFormat(""),bCaptionViewed(false),bColumnEditable(false),siColumnNumber(0),cViewType(0),ucJustify(0),ucColumnType(0),ucDateFormat(0),ValueWidth(0), ValueDecimals(0),WorkControl(NULL)
                 {}

TViewLine(const TViewLine& rvl)
	{
		if (this == &rvl)
		return;

	this->sLineName = rvl.sLineName;
	this->sColumnName = rvl.sColumnName;
	this->sExpression = rvl.sExpression;
	this->sValue = rvl.sValue;

	this->sExpressionIdentifier = rvl.sExpressionIdentifier;
	this->sExpressionValue = rvl.sExpressionValue;
	this->sExpressionViewedValue = rvl.sExpressionViewedValue;
	this->sListTable = rvl.sListTable;
	this->sAdditionalCondition = rvl.sAdditionalCondition;

	this->sCustomDateFormat = rvl.sCustomDateFormat;

    this->ListValues.clear();
    	for(TListValues::const_iterator i = rvl.ListValues.begin();i != rvl.ListValues.end();++i)
		this->ListValues.push_back(*i);
	this->bColumnEditable = rvl.bColumnEditable;
    bCaptionViewed = rvl.bCaptionViewed;
	this->siColumnNumber = rvl.siColumnNumber ;
	this->cViewType = rvl.cViewType;
    ucJustify = rvl.ucJustify;
	this->ucColumnType = rvl.ucColumnType;
	this->ucDateFormat = rvl.ucDateFormat;
	this->ValueWidth = rvl.ValueWidth;
	this->ValueDecimals = rvl.ValueDecimals;
		if (rvl.WorkControl != NULL)
		{
			this->DeleteWorkControl = false;
			this->WorkControl = rvl.WorkControl;
		}
		else
			this->WorkControl = NULL;
	}

    ~TViewLine()
    {
	clear();
    }

TViewLine& operator =(const TViewLine& rvl)
	{
		if (this == &rvl)
			return *this;
		this->sLineName = rvl.sLineName;
		this->sColumnName = rvl.sColumnName;
		this->sExpression = rvl.sExpression;
		this->sValue = rvl.sValue;
		this->sExpressionIdentifier = rvl.sExpressionIdentifier;
		this->sExpressionValue = rvl.sExpressionValue;
		this->sExpressionViewedValue = rvl.sExpressionViewedValue;
		this->sListTable = rvl.sListTable;
		this->sAdditionalCondition = rvl.sAdditionalCondition;
		this->sCustomDateFormat = rvl.sCustomDateFormat;

		this->ListValues.clear();
    	for(TListValues::const_iterator i = rvl.ListValues.begin();i != rvl.ListValues.end();++i)
			this->ListValues.push_back(*i);
		this->bColumnEditable = rvl.bColumnEditable;
		bCaptionViewed = rvl.bCaptionViewed;
		this->siColumnNumber = rvl.siColumnNumber ;
		this->cViewType = rvl.cViewType;
		ucJustify = rvl.ucJustify;
		this->ucColumnType = rvl.ucColumnType;
		this->ucDateFormat = rvl.ucDateFormat;
		this->ValueWidth = rvl.ValueWidth;
		this->ValueDecimals = rvl.ValueDecimals;
		try
        {
    		if (DeleteWorkControl == true && this->WorkControl != NULL)
				this->WorkControl->Free();
			DeleteWorkControl = false;
			WorkControl = rvl.WorkControl;
        }
        catch(...)
        {
			DeleteWorkControl = false;
			WorkControl = rvl.WorkControl;
        }
		return *this;
	}
};
typedef std::vector<TViewLine> TViewLines;

const char * const MapInfo_ThisTable = "#ThisTable";
const char * const MapInfo_CurrentRowId = "~CurrentRowId~";
const char * const MapInfo_CurrentTableName = "~CurrentTableName~";

bool ToTakeParametersOfAttributes(TMapInfo & MapInfo, const AnsiString & sTable,const int iRowID, TViewLines & ViewLines, AnsiString & sQueryExpressions,const bool bForCorrection);
bool ToSaveParametersOfAttributes(TMapInfo & MapInfo, AnsiString sTable,const TViewLines & ViewLines);
bool ToSaveParametersOfAttributes(TMapInfo & MapInfo, AnsiString sTable, TStrings * ItemViewLines);



#endif//INCLUDED_INFOTOOLPARAMETERSUNIT_H
//END
