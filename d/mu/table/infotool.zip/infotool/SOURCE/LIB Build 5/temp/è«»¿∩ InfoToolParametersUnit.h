/*********************************************************/
/*                                                       */
/*          ������ InfoToolParametersUnit                */
/*   ������ �������� ������� � ����������, ������������  */
/*   � ��������� InfoTool + � ����������� ��� ���������� */
/*   ���������� �������������� �����                     */
/*                                                       */
/*  Copyright (c) 2005-2006 �������� ���������           */
/*            buls@land.ru                               */
/*                                                       */
/*  �������������: 3.07.2006                             */
/*                                                       */
/*********************************************************/
#pragma once
#ifndef INCLUDED_INFOTOOLPARAMETERSUNIT_H
#define INCLUDED_INFOTOOLPARAMETERSUNIT_H
#include <windows.h>
#include <vcl.h>
#include <vector>
#include <limits>
#include <stdlib>
#include "BulsDdeErrorsUnit.h"
#include "BulsMapInfoConstUnit.h"
#include "BulsMapInfoUtilsUnit.h"
#include "BorderComponentsUnit.h"

using namespace std;

class TInfoToolComboBox: public TBorderComboBox
{
	typedef TBorderComboBox inherited;

public:

	class TBoundLabel: public TBorderBoundLabel
	{
		typedef TBorderBoundLabel inherited;
	private:

		void __fastcall CMMouseEnter( TMessage & Message)/* MESSAGE CM_MOUSEENTER */;
		void __fastcall CMMouseLeave( TMessage & Message)/* MESSAGE CM_MOUSELEAVE */;

		BEGIN_MESSAGE_MAP
		MESSAGE_HANDLER(CM_MOUSEENTER, TMessage, CMMouseEnter)
		MESSAGE_HANDLER(CM_MOUSELEAVE, TMessage, CMMouseLeave)
		END_MESSAGE_MAP(inherited)

	public:
		bool SelectNewTableRow;
		__fastcall TBoundLabel(Classes::TComponent* AOwner): inherited(AOwner),SelectNewTableRow(false)
		{
		Name = "TableRowSubLabel";
		};
	};

public:
	__fastcall TInfoToolComboBox(Classes::TComponent* AOwner);
	TCaption SavedValue;
	unsigned char ValueType;

	AnsiString SourceTable;
	AnsiString ExpressionIdentifier;
	AnsiString ExpressionValue;
	AnsiString ExpressionViewedValue;
	AnsiString AdditionalCondition;
	AnsiString CurrentValuesQuery;
};

class TInfoToolIntEdit: public TBorderEdit
{
	typedef TBorderEdit inherited;
private:
	int FMinValue,FMaxValue;
	void __fastcall WMPaste(TMessage & Message);
	void __fastcall CorrectValueOnMessage(TMessage & Message);
	void __fastcall WMChar(TWMKey &Message);
	void __fastcall WMKeyDown(TWMKey &Message);
protected:
	bool IsNegativeCurrentValue(AnsiString & Value);//������� ��������� ������� ����� �����
	virtual int InsertChar(AnsiString & Value,const char NewChar,int StartPosition,int FinishPosition);//������� ������� �������� �-� StartPosition � FinishPosition, � �� �� ����� ��������� ����� ������ NewChar
	/*virtual*/ int DeleteFirstNulls(AnsiString & Value);//������� ������� ������ ���� ������ ����� ��������
	/*virtual*/ void DeleteNoDigitSymbols(AnsiString & Value);//������� ������� ����������� �������
	virtual bool ToCheckValue(AnsiString & Value);//������� ��������� �� ������������ ������� � ���� ��������
	virtual void ToCorrectValue(AnsiString & Value);//������� ��������� �� ������������ ������� � ���� ��������
//	virtual void ToCorrectInputChar(char Value);//������� ��������� �� ������������ ������� � ���� ������

	BEGIN_MESSAGE_MAP
	MESSAGE_HANDLER(WM_PASTE, TMessage, CorrectValueOnMessage)
	MESSAGE_HANDLER(CM_EXIT, TMessage, CorrectValueOnMessage)
	MESSAGE_HANDLER(WM_KEYDOWN, TWMKey, WMKeyDown)
	MESSAGE_HANDLER(WM_CHAR, TWMKey, WMChar)
	END_MESSAGE_MAP(inherited)
public:
__fastcall TInfoToolIntEdit(Classes::TComponent* AOwner,int NewMinValue = INT_MIN,int NewMaxValue = INT_MAX);
};

class TInfoToolDecimalEdit: public TInfoToolIntEdit
{
	typedef TInfoToolIntEdit inherited;
protected:
	int FDigitsWidth /*,FIntegers*/, FDecimals;
private:
	double FMinValue,FMaxValue;
	bool InsertDecimalSeparatorChar(AnsiString & Value,const char NewChar,const int StartPosition,const int FinishPosition);
	int DecimalSeparatorPosition(AnsiString & Value);
//	void __fastcall WMPaste(TMessage & Message);
//	void __fastcall CorrectValueOnMessage(TMessage & Message);
	void __fastcall WMChar(TWMKey &Message);
protected:
	int GetCurrentValueWidth(AnsiString & Value);//������� ���������� ����� ������� ��������

	bool IsCorrectCharCountCurrentValue(AnsiString & Value);
	/*virtual*/ bool IsNullCurrentValue(AnsiString & Value);
	virtual int InsertChar(AnsiString & Value,const char NewChar,int StartPosition,int FinishPosition);
	/*virtual*/ int DeleteFirstNulls(AnsiString & Value);
	/*virtual*/ int DeleteLastNulls(AnsiString & Value);
	/*virtual*/ void DeleteNoDigitSymbols(AnsiString & Value);
	virtual bool ToCheckValue(AnsiString & Value);
	virtual void ToCorrectValue(AnsiString & Value);


	BEGIN_MESSAGE_MAP
//	MESSAGE_HANDLER(WM_PASTE, TMessage, CorrectValueOnMessage)
//	MESSAGE_HANDLER(CM_EXIT, TMessage, CorrectValueOnMessage)
	MESSAGE_HANDLER(WM_CHAR, TWMKey, WMChar)
	END_MESSAGE_MAP(inherited)
public:
__fastcall TInfoToolDecimalEdit(Classes::TComponent* AOwner,int NewWidth = 18,int NewDecplaces = -1,double NewMinValue = (-1.7e308 +1),double NewMaxValue = 1.7e+308);
};


struct TListValue
{
	AnsiString sViewedValue;
	AnsiString sSavedValue;
};

typedef std::vector<TListValue> TListValues;

class TViewLine
{
private:
	bool DeleteWorkControl;
public:
	AnsiString sLineName;
	AnsiString sColumnName;
	AnsiString sExpression;
	AnsiString sValue;
	AnsiString sExpressionIdentifier;
	AnsiString sExpressionValue;
	AnsiString sExpressionViewedValue;
	AnsiString sListTable;
	AnsiString sAdditionalCondition;
	AnsiString sCustomDateFormat;
	TListValues ListValues;
	bool bColumnEditable;
	bool bCaptionViewed;
	short siColumnNumber;
	char cViewType;
    unsigned char ucJustify;
	unsigned char ucColumnType;
	unsigned char ucDateFormat;
	unsigned char ValueWidth, ValueDecimals;
	TControl * WorkControl;

void clear()
    {
	sLineName = sColumnName = sExpression = sValue
    = sExpressionIdentifier = sExpressionValue = sListTable
    = sAdditionalCondition= sCustomDateFormat = "";

	ListValues.clear();
	bCaptionViewed = bColumnEditable = false;
	siColumnNumber = 0;
	cViewType = 0;
    ucColumnType = 0;
	ucDateFormat = 0;
	ValueWidth = 0;
	ValueDecimals = 0;
		try
		{
			if (DeleteWorkControl && (WorkControl != NULL))
				WorkControl->Free();
		WorkControl = NULL;
		}
		catch(...)
		{
		WorkControl = NULL;
		}
	}
TViewLine(): DeleteWorkControl(true),sLineName(""),sColumnName(""),sExpression(""),sValue(""),sExpressionIdentifier(""),sExpressionValue(""),
			sListTable(""),sAdditionalCondition(""),sCustomDateFormat(""),bCaptionViewed(false),bColumnEditable(false),siColumnNumber(0),cViewType(0),ucJustify(0),ucColumnType(0),ucDateFormat(0),ValueWidth(0), ValueDecimals(0),WorkControl(NULL)
                 {}

TViewLine(const TViewLine& rvl)
	{
		if (this == &rvl)
		return;

	this->sLineName = rvl.sLineName;
	this->sColumnName = rvl.sColumnName;
	this->sExpression = rvl.sExpression;
	this->sValue = rvl.sValue;

	this->sExpressionIdentifier = rvl.sExpressionIdentifier;
	this->sExpressionValue = rvl.sExpressionValue;
	this->sExpressionViewedValue = rvl.sExpressionViewedValue;
	this->sListTable = rvl.sListTable;
	this->sAdditionalCondition = rvl.sAdditionalCondition;

	this->sCustomDateFormat = rvl.sCustomDateFormat;

    this->ListValues.clear();
    	for(TListValues::const_iterator i = rvl.ListValues.begin();i != rvl.ListValues.end();++i)
		this->ListValues.push_back(*i);
	this->bColumnEditable = rvl.bColumnEditable;
    bCaptionViewed = rvl.bCaptionViewed;
	this->siColumnNumber = rvl.siColumnNumber ;
	this->cViewType = rvl.cViewType;
    ucJustify = rvl.ucJustify;
	this->ucColumnType = rvl.ucColumnType;
	this->ucDateFormat = rvl.ucDateFormat;
	this->ValueWidth = rvl.ValueWidth;
	this->ValueDecimals = rvl.ValueDecimals;
		if (rvl.WorkControl != NULL)
		{
			this->DeleteWorkControl = false;
			this->WorkControl = rvl.WorkControl;
		}
		else
			this->WorkControl = NULL;
	}

    ~TViewLine()
    {
	clear();
    }

TViewLine& operator =(const TViewLine& rvl)
	{
		if (this == &rvl)
			return *this;
		this->sLineName = rvl.sLineName;
		this->sColumnName = rvl.sColumnName;
		this->sExpression = rvl.sExpression;
		this->sValue = rvl.sValue;
		this->sExpressionIdentifier = rvl.sExpressionIdentifier;
		this->sExpressionValue = rvl.sExpressionValue;
		this->sExpressionViewedValue = rvl.sExpressionViewedValue;
		this->sListTable = rvl.sListTable;
		this->sAdditionalCondition = rvl.sAdditionalCondition;
		this->sCustomDateFormat = rvl.sCustomDateFormat;

		this->ListValues.clear();
    	for(TListValues::const_iterator i = rvl.ListValues.begin();i != rvl.ListValues.end();++i)
			this->ListValues.push_back(*i);
		this->bColumnEditable = rvl.bColumnEditable;
		bCaptionViewed = rvl.bCaptionViewed;
		this->siColumnNumber = rvl.siColumnNumber ;
		this->cViewType = rvl.cViewType;
		ucJustify = rvl.ucJustify;
		this->ucColumnType = rvl.ucColumnType;
		this->ucDateFormat = rvl.ucDateFormat;
		this->ValueWidth = rvl.ValueWidth;
		this->ValueDecimals = rvl.ValueDecimals;
		try
        {
    		if (DeleteWorkControl == true && this->WorkControl != NULL)
				this->WorkControl->Free();
			DeleteWorkControl = false;
			WorkControl = rvl.WorkControl;
        }
        catch(...)
        {
			DeleteWorkControl = false;
			WorkControl = rvl.WorkControl;
        }
		return *this;
	}
};
typedef std::vector<TViewLine> TViewLines;

const char * const MapInfo_ThisTable = "#ThisTable";
const char * const MapInfo_CurrentRowId = "~CurrentRowId~";
const char * const MapInfo_CurrentTableName = "~CurrentTableName~";

bool ToTakeParametersOfAttributes(TMapInfo & MapInfo, const AnsiString & sTable,const int iRowID, TViewLines & ViewLines, AnsiString & sQueryExpressions,const bool bForCorrection);
bool ToSaveParametersOfAttributes(TMapInfo & MapInfo, AnsiString sTable,const TViewLines & ViewLines);
bool ToSaveParametersOfAttributes(TMapInfo & MapInfo, AnsiString sTable, TStrings * ItemViewLines);



#endif//INCLUDED_INFOTOOLPARAMETERSUNIT_H
//END
