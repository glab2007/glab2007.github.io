//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SelectTableWindowUnit.h"
//---------------------------------------------------------------------------
//#pragma package(smart_init)
#pragma resource "*.dfm"
TSelectTableWindow *SelectTableWindow;
//---------------------------------------------------------------------------
__fastcall TSelectTableWindow::TSelectTableWindow(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSelectTableWindow::AllKeyPress(TObject *Sender, char &Key)
{
	switch (Key)
	{
		case Char(VK_TAB):
			Key = NULL;
			break;
	}
}
//---------------------------------------------------------------------------

void __fastcall TSelectTableWindow::CancelButtonClick(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------

