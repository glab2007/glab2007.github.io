/*********************************************************/
/*                                                       */
/*          ������ InfoToolComponentsUnit                */
/*    ������ �������� ����������, ������������           */
/*    � ��������� InfoTool +                             */
/*                                                       */
/*         Copyright (c) 2005-2006                       */
/*       �������� ��������� buls@land.ru                 */
/*                                                       */
/*    �������������: 29.07.2006                          */
/*                                                       */
/*********************************************************/
#pragma once
#ifndef INCLUDED_BORDERCOMPONENTSUNIT_H
#define INCLUDED_BORDERCOMPONENTSUNIT_H

#include <SysUtils.hpp>
#include <ComCtrls.hpp>
#include <Buttons.hpp>
#include <Graphics.hpp>
#include <typeinfo.h>


class TBorderBoundLabel: public TStaticText
{
	typedef TStaticText inherited;
private:
	void __fastcall CMTextChanged(TMessage & Message);

	void AdjustBounds();
protected:
	BEGIN_MESSAGE_MAP
	MESSAGE_HANDLER(CM_TEXTCHANGED, TMessage, CMTextChanged)
	END_MESSAGE_MAP(inherited)
	void __fastcall CreateParams(Controls::TCreateParams &Params);
public:
	__fastcall TBorderBoundLabel(Classes::TComponent* AOwner);
};

class TBorderEdit: public TEdit
{
	typedef TEdit inherited;
private:
    TBorderBoundLabel *FEditLabel;
    TLabelPosition FLabelPosition;
    int FLabelSpacing;
    TColor FBorderColor;
    void __fastcall SetLabelPosition( TLabelPosition const& Value);
    void __fastcall SetLabelSpacing( int const& Value);

    void __fastcall EraseBorder(TMessage & Message);

    void __fastcall CMVisibleChanged( TMessage & Message);
    void __fastcall CMEnabledChanged( TMessage & Message);
    void __fastcall CMBiDiModeChanged( TMessage & Message);


protected:

    void __fastcall SetParent(TWinControl* AParent);
    void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
    void __fastcall SetName(const AnsiString Value);

	BEGIN_MESSAGE_MAP
    MESSAGE_HANDLER(WM_NCPAINT, TMessage, EraseBorder)
	MESSAGE_HANDLER(CM_VISIBLECHANGED, TMessage, EraseBorder)
	MESSAGE_HANDLER(CM_ENABLEDCHANGED, TMessage, EraseBorder)
	MESSAGE_HANDLER(CM_BIDIMODECHANGED, TMessage, EraseBorder)
	END_MESSAGE_MAP(inherited)

public:
    void __fastcall SetBounds(int ALeft, int ATop, int AWidth, int AHeight);
    void SetupInternalLabel();
	__fastcall TBorderEdit(Classes::TComponent* AOwner);
	void UpdateLabelPosition();
__published:
	__property TColor BorderColor = {read=FBorderColor,write=FBorderColor,nodefault};
	__property TBorderBoundLabel * EditLabel = {read=FEditLabel,nodefault};
	__property TLabelPosition LabelPosition = {read=FLabelPosition,write=SetLabelPosition,nodefault};
	__property int LabelSpacing = {read=FLabelSpacing,write=SetLabelSpacing,nodefault};
};

class TBorderCheckBox: public TCheckBox
{
	typedef TCheckBox inherited;
private:
    bool FReadOnly;
    TColor FBorderColor;
    void __fastcall EraseCheckBox(TMessage & Message);
    void __fastcall SetCheck(TMessage & Message);

protected:
	virtual void __fastcall CreateWnd(void);

	BEGIN_MESSAGE_MAP
	MESSAGE_HANDLER(WM_PAINT, TMessage, EraseCheckBox)
	MESSAGE_HANDLER(BM_SETSTATE, TMessage, SetCheck)
	MESSAGE_HANDLER(BM_SETCHECK, TMessage, SetCheck)
	END_MESSAGE_MAP(inherited)

public:
	__fastcall TBorderCheckBox(Classes::TComponent* AOwner);
__published:
	__property TColor BorderColor = {read=FBorderColor,write=FBorderColor,nodefault};
    __property bool ReadOnly = {read=FReadOnly,write=FReadOnly,default=false};
};

class TBorderDateEdit: public TDateTimePicker
{
	typedef TDateTimePicker inherited;
private:
    bool FIsTouched;
    TLabelPosition FLabelPosition;
    int FLabelSpacing;
    TColor FBorderColor;
    bool FReadOnly;
    void __fastcall SetLabelPosition( TLabelPosition const& Value);
    void __fastcall SetLabelSpacing( int const& Value);

    void __fastcall EraseBorder(TMessage & Message);
	void __fastcall CNNotify(TWMNotify &Message);
    void __fastcall CMVisibleChanged( TMessage & Message);
    void __fastcall CMEnabledChanged( TMessage & Message);
    void __fastcall CMBiDiModeChanged( TMessage & Message);
  
protected:
    TBorderBoundLabel *FEditLabel;
    void __fastcall SetParent(TWinControl* AParent);
    void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
    void __fastcall SetName(const AnsiString Value);

    void __fastcall WndProc(Messages::TMessage &Message);

	BEGIN_MESSAGE_MAP
    MESSAGE_HANDLER(WM_NCPAINT, TMessage, EraseBorder)

	MESSAGE_HANDLER(CN_NOTIFY, TWMNotify, CNNotify)
	MESSAGE_HANDLER(CM_VISIBLECHANGED, TMessage, CMVisibleChanged)
	MESSAGE_HANDLER(CM_ENABLEDCHANGED, TMessage, CMEnabledChanged)
	MESSAGE_HANDLER(CM_BIDIMODECHANGED, TMessage, CMBiDiModeChanged)
	END_MESSAGE_MAP(inherited)

public:
	__fastcall TBorderDateEdit(Classes::TComponent* AOwner);
    void __fastcall SetBounds(int ALeft, int ATop, int AWidth, int AHeight);
    void SetupInternalLabel();
	void UpdateLabelPosition();
__published:
	__property TColor BorderColor = {read=FBorderColor,write=FBorderColor,nodefault};
	__property TBorderBoundLabel * EditLabel = {read=FEditLabel,nodefault};
	__property TLabelPosition LabelPosition = {read=FLabelPosition,write=SetLabelPosition,nodefault};
	__property int LabelSpacing = {read=FLabelSpacing,write=SetLabelSpacing,nodefault};
    __property bool ReadOnly = {read=FReadOnly,write=FReadOnly,default=false};
	__property bool IsTouched = {read=FIsTouched};
};

class TBorderComboBox: public TComboBox
{
	typedef TComboBox inherited;
private:
    TColor FBorderColor;
    bool FReadOnly;
    TCaption FDefaultValue;
	TLabelPosition FLabelPosition;
    int FLabelSpacing;
    void __fastcall SelectValue(System::TObject* Sender);

    void __fastcall SetLabelPosition( TLabelPosition const& Value);
    void __fastcall SetLabelSpacing( int const& Value);

    void __fastcall EraseBorder(TMessage & Message);
    void __fastcall WMLButtonUp(TMessage & Message);
	void __fastcall CMExit( TMessage & Message);

	void __fastcall CMVisibleChanged( TMessage & Message);
	void __fastcall CMEnabledChanged( TMessage & Message);
	void __fastcall CMBiDiModeChanged( TMessage & Message);

	void __fastcall CBShowDropDown(TMessage & Message);
protected:
	TBorderBoundLabel *FEditLabel;

	void __fastcall SetParent(TWinControl* AParent);
	void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	void __fastcall SetName(const AnsiString Value);

    BEGIN_MESSAGE_MAP
    MESSAGE_HANDLER(WM_NCPAINT, TMessage, EraseBorder)
	MESSAGE_HANDLER(WM_PAINT, TMessage, EraseBorder)
	MESSAGE_HANDLER(WM_LBUTTONUP, TMessage, WMLButtonUp)

	MESSAGE_HANDLER(CB_SHOWDROPDOWN, TMessage, CBShowDropDown)

	MESSAGE_HANDLER(CM_EXIT, TMessage, CMExit)
	MESSAGE_HANDLER(CM_VISIBLECHANGED, TMessage, CMVisibleChanged)
	MESSAGE_HANDLER(CM_ENABLEDCHANGED, TMessage, CMEnabledChanged)
	MESSAGE_HANDLER(CM_BIDIMODECHANGED, TMessage, CMBiDiModeChanged)
	END_MESSAGE_MAP(inherited)
  
public:
	__fastcall TBorderComboBox(Classes::TComponent* AOwner);
    void __fastcall SetBounds(int ALeft, int ATop, int AWidth, int AHeight);
    void SetupInternalLabel();
	void UpdateLabelPosition();
__published:
	__property TColor BorderColor = {read=FBorderColor,write=FBorderColor,nodefault};
	__property TBorderBoundLabel * EditLabel = {read=FEditLabel,nodefault};
	__property TLabelPosition LabelPosition = {read=FLabelPosition,write=SetLabelPosition,nodefault};
	__property int LabelSpacing = {read=FLabelSpacing,write=SetLabelSpacing,nodefault};
	__property bool ReadOnly = {read=FReadOnly,write=FReadOnly,default=false};
    __property TCaption DefaultValue = {read=FDefaultValue,write=FDefaultValue,nodefault};
};

//Controls__11 CMyEditStyle = ( csClickEvents , csSetCaption , csDoubleClicks , csFixedHeight, csOpaque );

#endif
