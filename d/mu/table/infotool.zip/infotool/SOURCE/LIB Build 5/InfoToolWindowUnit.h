//---------------------------------------------------------------------------

#ifndef InfoToolWindowUnitH
#define InfoToolWindowUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>

#include "EditValueUnit.h"
#include "BulsMapInfoUtilsUnit.h"
#include "BorderBitBtn.h"
#include "WindowDivider.h"

enum TBeakPosition { bpTopLeft, bpTopRight, bpBottomLeft, bpBottomRight };
typedef Set<TBeakPosition, bpTopLeft, bpBottomRight>  TBeakPositions;

//---------------------------------------------------------------------------
class TInfoToolWindow : public TForm
{
public:
	TBorderBitBtn * ButtonSave;
	TBorderBitBtn * ButtonClose;
__published:	// IDE-managed Components
	TScrollBox *ScrollBox;
	void __fastcall AllKeyPress(TObject *Sender, char &Key);
	void __fastcall ButtonSaveClick(TObject *Sender);
	void __fastcall ButtonCloseClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);
public:
    int FRowId;
    int FCurrentMapWindowId;
    AnsiString FTableName;
    int FAdditionalWindowId;
    bool FSavingStarted; bool FFindingStarted;
private:
    AnsiString FQueryExpressionsName;

    void * FSelValueWndInstance;
    TMapInfo FMapInfo;
    TInfoToolComboBox * FCurrentComboBox;
	TViewLines FViewLines;
    FARPROC FOldSelValueWndProc;
    HWND FSelValueWnd;
    int FSelValueWindowId;
    HWND FAdditionalWindow;
    short FAverageLineHeight; short FMaxCaptionLength;
    TEditValueWindow * FEditValueWindow;

	void __fastcall EditValueWindow_OkButtonClick(TObject *Sender);
	void __fastcall EditValueWindow_Close(TObject * Sender,  TCloseAction & Action);

	void __fastcall WMSizing(TMessage & Message);
	void __fastcall WMSetCursor( TWMSetCursor & Message);
    void __fastcall WMPaint( TWMPaint & Message);
	void __fastcall WMWindowPosChanging( TWMWindowPosChanging & Message);
	void __fastcall CreateParams( TCreateParams & Params);
	void __fastcall SelValueWndProc( TMessage & Msg);

	BEGIN_MESSAGE_MAP
	MESSAGE_HANDLER(WM_SIZING, TMessage, WMSizing)
	MESSAGE_HANDLER(WM_SETCURSOR, TWMSetCursor, WMSetCursor)
	MESSAGE_HANDLER(WM_PAINT, TWMPaint, WMPaint)
	MESSAGE_HANDLER(WM_WINDOWPOSCHANGING, TWMWindowPosChanging, WMWindowPosChanging)
	END_MESSAGE_MAP(TForm)

    bool CreateNewSelValueWindow(bool ReadOnly, AnsiString & FoundValue);
	void FindValueInBrowse();
	bool CreateAdditionalWindow();
	bool CreateInfoFields();
	bool TakeParametersInfoFields();
    void SetFrameHeight(short siHeight,  short siMinHeight,  short siMaxHeight);
	void __fastcall ComboBoxLabelMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
public:
	__fastcall TInfoToolWindow(TComponent* Owner,HCONV NewMapInfoDDEConv, HCONV NewApplicationDDEConv, int NewDdeInstId);
	__fastcall TInfoToolWindow(TComponent* Owner);
	virtual __fastcall ~TInfoToolWindow();
	bool StartInfoToolWindow();
    void ShowAt(int X, int Y,  TBeakPosition BP);
    __property TMapInfo MapInfo = { read=FMapInfo };
    __property TEditValueWindow * EditValueWindow = { read=FEditValueWindow };
	__property TInfoToolComboBox * CurrentComboBox = { read=FCurrentComboBox };
    __property HWND SelValueWnd = { read=FSelValueWnd };
    __property int SelValueWindowId = { read=FSelValueWindowId };
};

//const char MapInfoDim_ApplicationIdentifier[] = "iGlobalApplicationIdentifier";
const char MapInfo_InternalProcedureAddCreationOfValue[] = "*#Internal Procedure:AddCreationOfValue";
const char MapInfo_InternalProcedureAddUpdatingOfValue[] = "*#Internal Procedure:AddUpdatingOfValue";
const char MapInfo_InternalProcedureRemoveCreationOfValue[] = "*#Internal Procedure:RemoveCreationOfValue";
const char MapInfo_InternalProcedureRemoveUpdatingOfValue[] = "*#Internal Procedure:RemoveUpdatingOfValue";
            
bool bToFindValueInBrowse = true; // ����������� ����� �������� �������� � ������, ����� ��� �����, ������������ �������� �� �������������� �������
bool bToSelectObjectInMap = true; // ����������� ��������� ���������� �������
int iStartFiledsCount = 0; // ���������� �����, ������������ �� ����� �������� ��������������� ����, 0 - ����������� ��� ����

extern "C"
{
void APIENTRY __declspec(dllexport) DestroyInfoToolWindow();
bool APIENTRY __declspec(dllexport) IsInfoToolWindowOpened();
void APIENTRY __declspec(dllexport) ViewInfoToolWindow
(short siScreenX,short siScreenY,  LPSTR lpstrTable,  int iRowID,
int iMapWindowId,  HWND hMapWindow,int iDdeInstId,  HCONV hMapinfoDdeConv,
HCONV hApplicationDdeconv,  LPSTR lpstrOptionsSection);
bool APIENTRY __declspec(dllexport) IsSavingStarted();
bool APIENTRY __declspec(dllexport) IsFindingStarted();
int APIENTRY __declspec(dllexport) GetCurrentAdditionalWindow();
void APIENTRY __declspec(dllexport) SetApplicationWindowHandle(int Handle);
void APIENTRY __declspec(dllexport) UpdateValue(void);
void APIENTRY __declspec(dllexport) NewValue(void);
}
//---------------------------------------------------------------------------
extern PACKAGE TInfoToolWindow *InfoToolWindow;
//---------------------------------------------------------------------------
#endif
