//---------------------------------------------------------------------------

#include <vcl.h>

#pragma hdrstop

#include "WindowDivider.h"
//#pragma package(smart_init)
//---------------------------------------------------------------------------
// ValidCtrCheck is used to assure that the components created do not have
// any pure virtual functions.
//

static inline void ValidCtrCheck(TWindowDivider *)
{
	new TWindowDivider(NULL);
}
//---------------------------------------------------------------------------
__fastcall TWindowDivider::TWindowDivider(TComponent* Owner)
	: TLabel(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TWindowDivider::AdjustBounds(void)
{
	inherited::AdjustBounds();
	if (AutoSize)
	{
		if (Caption.Length() == 0)
			Height = BorderWeight;
		else
		{
			if (Layout != tlCenter)
				Height = Height + BorderWeight;
		}
	}
}

void __fastcall TWindowDivider::DoDrawText(Types::TRect &Rect, int Flags)
{
	if (Caption.Length() == 0)
	{
		if ((Flags | DT_CALCRECT) != Flags)
			DrawEdge(Canvas->Handle,&Rect,EDGE_ETCHED,BF_TOP);
		else
			Flags -= DT_CALCRECT;
	}
	else if ((Flags | DT_CALCRECT) != Flags)
	{
		if (this->Layout == tlTop)
		{
			TRect CalcRect(Rect);
			Flags = Flags | DT_CALCRECT;
			inherited::DoDrawText(CalcRect,Flags);
			Flags = Flags ^ DT_CALCRECT;
			CalcRect.left = Rect.left;
			CalcRect.right = Rect.right;
			CalcRect.bottom = CalcRect.bottom+BorderWeight;
			DrawEdge(Canvas->Handle,&CalcRect,EDGE_ETCHED,BF_BOTTOM);
		}
		else if (this->Layout == tlBottom)
		{
			Rect.top = Rect.top-BorderWeight;
			DrawEdge(Canvas->Handle,&Rect,EDGE_ETCHED,BF_TOP);
			Rect.top = Rect.top+BorderWeight;
		}
		else if (this->Layout == tlCenter)
		{
			TRect TextRect(Rect),CalcRect = GetClientRect();
			OffsetRect(&CalcRect,0,(Rect.top-Rect.bottom) / 2);
			Flags = Flags | DT_CALCRECT;
			inherited::DoDrawText(TextRect,Flags);
			Flags = Flags ^ DT_CALCRECT;

			if (this->Alignment == taLeftJustify)
			{
				CalcRect.left = TextRect.right+BorderWeight;
				DrawEdge(Canvas->Handle,&CalcRect,EDGE_ETCHED,BF_BOTTOM);
			}
			if (this->Alignment == taRightJustify)
			{
				CalcRect.Right= CalcRect.Right - TextRect.right - BorderWeight;
				DrawEdge(Canvas->Handle,&CalcRect,EDGE_ETCHED,BF_BOTTOM);
			}
			if (this->Alignment == taCenter)
			{
				CalcRect.right = ((CalcRect.right - TextRect.right) / 2) - BorderWeight;
				DrawEdge(Canvas->Handle,&CalcRect,EDGE_ETCHED,BF_BOTTOM);
				CalcRect.left = CalcRect.right+TextRect.right +BorderWeight*2;
				CalcRect.right = Rect.right;
				DrawEdge(Canvas->Handle,&CalcRect,EDGE_ETCHED,BF_BOTTOM);
			}
		}
	}
	inherited::DoDrawText(Rect,Flags);
}

namespace Windowdivider
{
	void __fastcall PACKAGE Register()
	{
		TComponentClass classes[1] = {__classid(TWindowDivider)};
		RegisterComponents("Samples", classes, 0);
	}
}
//---------------------------------------------------------------------------
