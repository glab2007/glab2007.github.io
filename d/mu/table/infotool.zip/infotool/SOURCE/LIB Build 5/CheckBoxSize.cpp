//---------------------------------------------------------------------------

#include <SysUtils.hpp>
#include "CheckBoxSize.h"
#pragma hdrstop

//---------------------------------------------------------------------------

//#pragma package(smart_init)

TCheckBoxSize DefaultCheckBoxSize;

TCheckBoxSize::TCheckBoxSize()
{
	BITMAP Bitmap;
	HDC DC = GetWindowDC( GetDesktopWindow() );
	HBITMAP handleBitmap = LoadBitmap( 0 , MAKEINTRESOURCE(OBM_CHECKBOXES));

		if (GetObject(handleBitmap,sizeof(Bitmap),&Bitmap) > 0)
		{
			Width = Bitmap.bmWidth / 4;
			Height = Bitmap.bmHeight / 3;
		}
	DeleteObject(handleBitmap);
	ReleaseDC( GetDesktopWindow(), DC );
}