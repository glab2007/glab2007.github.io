//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "NewFieldWindowUnit.h"
//---------------------------------------------------------------------------
//#pragma package(smart_init)
#pragma resource "*.dfm"
TNewFieldWindow *NewFieldWindow;
//---------------------------------------------------------------------------
__fastcall TNewFieldWindow::TNewFieldWindow(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TNewFieldWindow::AllKeyPress(TObject *Sender, char &Key)
{
	switch (Key)
	{
		case Char(VK_TAB):
			Key = NULL;
			break;
	}
}
//---------------------------------------------------------------------------
void __fastcall TNewFieldWindow::CancelButtonClick(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------


void __fastcall TNewFieldWindow::DividerCheckClick(TObject *Sender)
{
	if (DividerCheck->Checked)
		this->ColumnName->Enabled = false;
	else
		this->ColumnName->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TNewFieldWindow::DividerCheckMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
	if (DividerCheck->Checked)
		this->ColumnName->Enabled = false;
	else
		this->ColumnName->Enabled = true;
}
//---------------------------------------------------------------------------

