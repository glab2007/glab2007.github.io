//---------------------------------------------------------------------------

#ifndef BorderBitBtnH
#define BorderBitBtnH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <Buttons.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
//---------------------------------------------------------------------------
class PACKAGE TBorderBitBtn : public TBitBtn
{
	typedef Buttons::TBitBtn inherited;
private:
	TColor FBorderColor;
    void __fastcall EraseBorder(TMessage & Message);

	void __fastcall CMMouseEnter( TMessage & Message);
	void __fastcall CMMouseLeave( TMessage & Message);
protected:
	BEGIN_MESSAGE_MAP
	MESSAGE_HANDLER(WM_PAINT, TMessage, EraseBorder)
	MESSAGE_HANDLER(CN_DRAWITEM, TMessage, EraseBorder)
	MESSAGE_HANDLER(CM_MOUSEENTER, TMessage, CMMouseEnter)
	MESSAGE_HANDLER(CM_MOUSELEAVE, TMessage, CMMouseLeave)
	END_MESSAGE_MAP(inherited)
public:
	__fastcall TBorderBitBtn(Classes::TComponent* AOwner);
__published:
	__property TColor BorderColor = {read=FBorderColor,write=FBorderColor,nodefault};
};
//---------------------------------------------------------------------------
#endif
