//---------------------------------------------------------------------------

#ifndef NewFieldWindowUnitH
#define NewFieldWindowUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TNewFieldWindow : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label2;
        TEdit *FieldName;
        TLabel *Label1;
        TComboBox *ColumnName;
        TBitBtn *OkButton;
        TBitBtn *CancelButton;
	TCheckBox *DividerCheck;
        void __fastcall AllKeyPress(TObject *Sender, char &Key);
	void __fastcall CancelButtonClick(TObject *Sender);
	void __fastcall DividerCheckClick(TObject *Sender);
	void __fastcall DividerCheckMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
private:	// User declarations
public:		// User declarations
        __fastcall TNewFieldWindow(TComponent* Owner);
  int FCountColumns,
  FChangeableField;
};
//---------------------------------------------------------------------------
extern PACKAGE TNewFieldWindow *NewFieldWindow;
//---------------------------------------------------------------------------
#endif
