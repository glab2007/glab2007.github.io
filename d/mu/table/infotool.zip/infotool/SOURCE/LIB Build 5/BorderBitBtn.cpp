//---------------------------------------------------------------------------

#include <vcl.h>

#pragma hdrstop

#include "BorderBitBtn.h"
//#pragma package(smart_init)
//---------------------------------------------------------------------------
// ValidCtrCheck is used to assure that the components created do not have
// any pure virtual functions.
//

inline void DrawButtonBorder(TWinControl * WinControl, TColor BorderColor, TColor Color)
{
	HDC DC = GetWindowDC( WinControl->Handle );
	HBRUSH Brush;
	TRect R;

	if ((BorderColor >= clScrollBar) && (BorderColor <= clMenuBar))
		BorderColor = (TColor)GetSysColor(BorderColor - clScrollBar);

	if ((Color >= clScrollBar) && (Color <= clMenuBar))
		Color = (TColor)GetSysColor(Color - clScrollBar);

	GetWindowRect( WinControl->Handle , &R );
	OffsetRect( R , -R.Left , -R.Top );

	Brush = CreateSolidBrush( Color );
	FrameRect( DC , &R , Brush );
	DeleteObject( Brush );

	InflateRect(&R, -1, -1);

	Brush = CreateSolidBrush( BorderColor );
	FrameRect( DC , &R , Brush );
	DeleteObject( Brush );

	Brush = CreateSolidBrush( Color );
	R = Rect( R.Left + 1 , R.Top + 1 , R.Right - 1 , R.Bottom - 1 );
	FrameRect( DC , &R , Brush );
	DeleteObject( Brush );

	ReleaseDC( WinControl->Handle , DC );
}


static inline void ValidCtrCheck(TBorderBitBtn *)
{
	new TBorderBitBtn(NULL);
}
//---------------------------------------------------------------------------

/* TBorderBitBtn */
__fastcall TBorderBitBtn::TBorderBitBtn(TComponent* Owner)
	: TBitBtn(Owner)
{
	BorderColor = static_cast<TColor>(0x00B99D7F);
}


void __fastcall TBorderBitBtn::EraseBorder( TMessage & Message)
{
	inherited::Dispatch(&Message);
	if (this->Focused())
		DrawButtonBorder( this , FBorderColor , Color );
	else
		DrawButtonBorder( this , Color , Color );
}

void __fastcall TBorderBitBtn::CMMouseEnter( TMessage & Message)
{
	inherited::Dispatch(&Message);
	if (!this->Focused())
		DrawButtonBorder( this , clSilver , Color );
}

void __fastcall TBorderBitBtn::CMMouseLeave( TMessage & Message)
{
	inherited::Dispatch(&Message);
	if (!this->Focused())
		DrawButtonBorder( this , Color , Color );
}
//---------------------------------------------------------------------------
namespace Borderbitbtn
{
	void __fastcall PACKAGE Register()
	{
		TComponentClass classes[1] = {__classid(TBorderBitBtn)};
		RegisterComponents("Samples", classes, 0);
	}
}
//---------------------------------------------------------------------------
 