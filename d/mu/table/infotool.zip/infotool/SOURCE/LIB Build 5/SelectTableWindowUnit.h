//---------------------------------------------------------------------------

#ifndef SelectTableWindowUnitH
#define SelectTableWindowUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TSelectTableWindow : public TForm
{
__published:	// IDE-managed Components
        TBitBtn *OkButton;
        TBitBtn *CancelButton;
        TComboBox *ComboBox1;
        void __fastcall AllKeyPress(TObject *Sender, char &Key);
	void __fastcall CancelButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TSelectTableWindow(TComponent* Owner);
};
//---------------------------------------------------------------------------
//extern PACKAGE TSelectTableWindow *SelectTableWindow;
//---------------------------------------------------------------------------
#endif
