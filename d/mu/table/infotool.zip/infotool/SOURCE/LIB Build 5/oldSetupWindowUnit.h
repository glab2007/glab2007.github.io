/**   @file  
     @brief  
*/
#pragma once
#ifndef INCLUDED_SETUPWINDOWUNIT_H
#define INCLUDED_SETUPWINDOWUNIT_H
/*********************************************************/
/*                                                       */
/*          ������ SetupWindowUnit                       */
/*   ������, �������� ����, ����������� �����������      */
/*   ��������� ����������� ����� � �������������� ����   */
/*                                                       */
/*  Copyright (c) 2005 �������� ��������� buls@land.ru   */
/*                                                       */
/*  �������������: 3.11.2005                             */
/*                                                       */
/*********************************************************/

 




  
#include "Windows.h" 
#include "Messages.h" 
#include "Forms.h"
#include "StdCtrls.h" 
#include "Buttons.h"
  
#include "Classes.h"
//  , Controls
   
#include "Menus.h"
#include "Ddeml.h" 
#include "ValEdit.h" 
#include "Grids.h" 
#include "SysUtils.h" 
#include "Graphics.h"
  
#include "InfoToolcomponentsunit.h"
#include "BulsMapinfoUtilsUnit.h"
#include "BulsMapinfoConstUnit.h"
#include "RunInfoToolUnit.h"
  
#include "SelectTableWindowUnit.h"
#include "NewFieldwindowUnit.h"
#include "EnterExpressionWindowUnit.h"
  
#include "InfoToolParametersUnit.h"
  
#include "BulsVclEventsTranslatorUnit.h" 
#include "Controls.h"
  

  
  
struct/*class*/ TListBox: public StdCtrls::TListBox
  
{
private:
  TNotifyEvent FOnAddString;
//  FOnSETITEMDATA:TNotifyEvent;
    void LBAddString( TMessage & Msg)/* MESSAGE LB_ADDSTRING */;  
  
};


  
struct/*class*/ TComboBox: public StdCtrls::TComboBox
  
{
protected:
  void SetItemIndex( int const& Value)/*override*/; 
  
};


  
struct/*class*/ TSetupWindow: public TForm
    
{TGroupBox FieldProperties;
    TMainMenu MainMenu1;
    TMenuItem N1;
    TMenuItem SaveChanges;
    TMenuItem N3;
    TMenuItem SelectTable;
    TMenuItem CloseWindow;
    TLabel LabelFieldType;
    TComboBox FieldType;
    TCheckBox FieldEnabled;
    TScrollBox StaticListOptions;
    TGroupBox ColumnsGroup;
    TScrollBox TableFieldOptions;
    TLabel LabelTableName;
    TComboBox ValuesTableName;
    TGroupBox GroupBox1;
    TLabel LabelValue;
    TLabel LabelIdentifier;
    TComboBox ValueColumn;
    TComboBox IdentifierColumn;
    TValueListEditor ValueList;
    TBitBtn CreateValue;
    TBitBtn DeleteValue;
    TLabel LabelCondition;
    TBitBtn CheckUp;
    TMemo AdditionalCondition;
    TGroupBox Fields;
    TBitBtn DeleteField;
    TBitBtn CreateField;
    TListBox ListFields;
    TBitBtn FieldUp;
    TBitBtn FieldDown;
    void FormCreate(TObject Sender);
    void FormClose(TObject Sender,   TCloseAction & Action);
    void ListFieldsClick(TObject Sender);
    void CreateFieldClick(TObject Sender);
    void DeleteFieldClick(TObject Sender);
    void FieldUpClick(TObject Sender);
    void FieldDownClick(TObject Sender);
    void FieldTypeSelect(TObject Sender);
    void ValuesTableNameSelect(TObject Sender);
    void DeleteValueClick(TObject Sender);
    void CreateValueClick(TObject Sender);
    void CloseWindowClick(TObject Sender);
    void SaveChangesClick(TObject Sender);
    void SelectTableClick(TObject Sender);
    void ListFieldsDblClick(TObject Sender);
    void CheckUpClick(TObject Sender);
    void KeyPress(TObject Sender,   char & Key);
    void FormDestroy(TObject Sender);
    void FormResize(TObject Sender);
  
private:
  int FOldHintHidePause;
  TMapInfo FMapInfo;
  int FCurrentField;
  AnsiString FTableName;
  Pointer FTaskWindowList;
  TViewLines FViewLines;
  TSelectTableWindow FSelectTableWindow;
  TNewFieldWindow FNewFieldWindow;
  TEnterExpressionWindow FEnterExpressionWindow;
    void SelectTableWindow_OkButtonClick(TObject Sender);
    void SelectTableWindow_CancelButtonClick(TObject Sender);
    void ChildFormClose(TObject Sender,   TCloseAction & Action);
    void NewFieldWindow_SelectColumn(TObject Sender);
    void NewFieldWindow_OkButtonClick(TObject Sender);
    void EnterExpressionWindow_OkButtonClick(TObject Sender);
    void EnterExpressionWindow_CheckUpClick(TObject Sender);
    void WMSIZING( TMessage & Message)/* MESSAGE WM_SIZING */;  
  
public:
    /*?*/static/*CONSTRUCTOR*/void Create(TComponent AOwner, hConv NewMapinfoDDEConv, hConv NewApplicationDDEConv, int NewDdeInstId);
    /*?*/static/*DESTRUCTOR*/void Destroy();
    void SelectNewTable();
    /*?*//*PROPERTY  MapInfo: TMapInfo read FMapInfo write FMapInfo;
     *//*?*//*PROPERTY  CurrentField: Integer read FCurrentField write FCurrentField;
     *//*?*//*PROPERTY  TableName: AnsiString read FTableName write FTableName;
     *//*?*//*PROPERTY  ViewLines: TViewLines read FViewLines write FViewLines;
   */
};

  



#endif//INCLUDED_SETUPWINDOWUNIT_H
//END
