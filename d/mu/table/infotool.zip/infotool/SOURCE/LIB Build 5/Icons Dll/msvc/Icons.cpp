// Icons.cpp : Defines the entry point for the DLL application.
//

int __stdcall main(int arg1,int arg2, int arg3)
{
    return 1;
}

