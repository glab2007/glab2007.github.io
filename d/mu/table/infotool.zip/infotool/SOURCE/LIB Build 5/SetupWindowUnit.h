/*********************************************************/
/*                                                       */
/*          ������ SetupWindowUnit                       */
/*   ������, �������� ����, ����������� �����������      */
/*   ��������� ����������� ����� � �������������� ����   */
/*                                                       */
/*  Copyright (c) 2005-2006 �������� ���������           */
/*            buls@land.ru                               */
/*                                                       */
/*  �������������: 17.07.2006                             */
/*                                                       */
/*********************************************************/
//---------------------------------------------------------------------------

#ifndef SetupWindowUnitH
#define SetupWindowUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Grids.hpp>
#include <Menus.hpp>
#include <ValEdit.hpp>

#include "SelectTableWindowUnit.h"
#include "NewFieldwindowUnit.h"
#include "EnterExpressionWindowUnit.h"

#include "InfoToolParametersUnit.h"
#include "BulsMapInfoUtilsUnit.h"
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------

class TSetupWindow : public TForm
{

__published:	// IDE-managed Components
        TMainMenu *MainMenu1;
        TMenuItem *N1;
        TMenuItem *SaveChanges;
        TMenuItem *N3;
        TMenuItem *SelectTable;
        TMenuItem *CloseWindow;
        TGroupBox *Fields;
        TBitBtn *DeleteField;
        TBitBtn *CreateField;
        TListBox *ListFields;
        TBitBtn *FieldUp;
        TBitBtn *FieldDown;
        TGroupBox *FieldProperties;
        TLabel *LabelFieldType;
        TComboBox *FieldType;
        TScrollBox *StaticListOptions;
        TGroupBox *ColumnsGroup;
        TValueListEditor *ValueList;
        TBitBtn *CreateValue;
        TBitBtn *DeleteValue;
        TScrollBox *TableFieldOptions;
        TLabel *LabelTableName;
        TLabel *LabelCondition;
        TComboBox *ValuesTableName;
        TGroupBox *GroupBox1;
        TLabel *LabelValue;
	TLabel *LabelViewedColumn;
        TComboBox *ValueColumn;
	TComboBox *ViewedColumn;
        TBitBtn *CheckUp;
        TMemo *AdditionalCondition;
	TScrollBox *DateFieldOptions;
	TLabel *LabelDateFormat;
	TComboBox *DateFormat;
	TLabel *LabelCustomDateFormat;
	TComboBox *CustomDateFormat;
	TCheckBox *CaptionViewed;
	TCheckBox *FieldEnabled;
	TRadioGroup *CaptionJustify;
	TComboBox *IdentifierColumn;
	TLabel *LabelIdentifier;
	TCheckBox *FullValuesVistCreated;
        void __fastcall AllKeyPress(TObject *Sender, char &Key);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall SaveChangesClick(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall ListFieldsClick(TObject *Sender);
	void __fastcall FieldTypeSelect(TObject *Sender);
	void __fastcall ValuesTableNameSelect(TObject *Sender);
	void __fastcall CheckUpClick(TObject *Sender);
	void __fastcall CreateValueClick(TObject *Sender);
	void __fastcall DeleteValueClick(TObject *Sender);
	void __fastcall FieldDownClick(TObject *Sender);
	void __fastcall CreateFieldClick(TObject *Sender);
	void __fastcall DeleteFieldClick(TObject *Sender);
	void __fastcall CloseWindowClick(TObject *Sender);
	void __fastcall SelectTableClick(TObject *Sender);
	void __fastcall FormResize(TObject *Sender);
	void __fastcall FormKeyPress(TObject *Sender, char &Key);
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
	void __fastcall CustomDateFormatChange(TObject *Sender);
	void __fastcall CustomDateFormatSelect(TObject *Sender);
	void __fastcall CaptionViewedClick(TObject *Sender);
	void __fastcall ListFieldsDblClick(TObject *Sender);
	void __fastcall ListFieldsDrawItem(TWinControl *Control, int Index,
          TRect &Rect, TOwnerDrawState State);
	void __fastcall FieldUpClick(TObject *Sender);
	void __fastcall FieldEnabledClick(TObject *Sender);
private:	// User declarations
	int FOldHintHidePause,FOldHintPause;
	TMapInfo FMapInfo;
	int FCurrentField;
	AnsiString FTableName;
	Pointer FTaskWindowList;
	TViewLines FViewLines;
	TSelectTableWindow * FSelectTableWindow;
	TNewFieldWindow * FNewFieldWindow;
	TEnterExpressionWindow * FEnterExpressionWindow;

	void __fastcall SelectTableWindow_OkButtonClick(TObject *Sender);
	void __fastcall SelectTableWindow_CancelButtonClick(TObject *Sender);
	void __fastcall ChildFormClose(TObject *Sender,   TCloseAction & Action);
	void __fastcall NewFieldWindow_SelectColumn(TObject *Sender);
	void __fastcall NewFieldWindow_OkButtonClick(TObject *Sender);
	void __fastcall EnterExpressionWindow_OkButtonClick(TObject *Sender);
	void __fastcall EnterExpressionWindow_CheckUpClick(TObject *Sender);

	void __fastcall WMSizing(TMessage & Message);

	BEGIN_MESSAGE_MAP
	MESSAGE_HANDLER(WM_SIZING, TMessage, WMSizing)
	END_MESSAGE_MAP(TForm)

	TWndMethod OldListBoxWindowProc; //������ ������� ������� ������ �����
	TWndMethod OldFieldTypeWindowProc; //������ ������� ������� ������ ����� �����
	void __fastcall ListBoxWindowProc(TMessage &Message); //����� ������� ������� ������ �����
	void __fastcall FieldTypeWindowProc(TMessage &Message); //����� ������� ������� ������ ����� �����

public:		// User declarations
	__fastcall TSetupWindow(TComponent* Owner,HCONV NewMapInfoDDEConv, HCONV NewApplicationDDEConv, int NewDdeInstId);
	__fastcall TSetupWindow(TComponent* Owner);
	virtual __fastcall ~TSetupWindow();
	void SelectNewTable();
};
//---------------------------------------------------------------------------
extern PACKAGE TSetupWindow *SetupWindow;
//---------------------------------------------------------------------------

extern "C"
{
	void APIENTRY __declspec(dllexport) DestroySetupWindow();
	void APIENTRY __declspec(dllexport) ViewSetupTable(int iDdeInstId,  HCONV hMapinfoDdeConv, HCONV hApplicationDdeConv);
}
#endif
