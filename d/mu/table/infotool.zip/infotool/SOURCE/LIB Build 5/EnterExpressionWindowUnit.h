//---------------------------------------------------------------------------

#ifndef EnterExpressionWindowUnitH
#define EnterExpressionWindowUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TEnterExpressionWindow : public TForm
{
__published:	// IDE-managed Components
        TMemo *Expression;
        TBitBtn *CheckUp;
        TBitBtn *OkButton;
        TBitBtn *CancelButton;
        void __fastcall AllKeyPress(TObject *Sender, char &Key);
	void __fastcall CancelButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TEnterExpressionWindow(TComponent* Owner);
TComboBox *FListOfExpressions;
};
//---------------------------------------------------------------------------
extern PACKAGE TEnterExpressionWindow *EnterExpressionWindow;
//---------------------------------------------------------------------------
#endif
