//---------------------------------------------------------------------------

#ifndef EditValueUnitH
#define EditValueUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TEditValueWindow : public TForm
{
__published:	// IDE-managed Components
	TBitBtn *CancelButton;
	TBitBtn *OkButton;
	TMemo *Value;
	TDateTimePicker *DateValue;
	void __fastcall AllKeyPress(TObject *Sender, char &Key);
	void __fastcall CancelButtonClick(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
	int DistanceAfterEditControl;//���������� �� ������� ���� ����� �� ������� ���� ��������
public:		// User declarations
	__fastcall TEditValueWindow(TComponent* Owner);
	 void ShowDateEdit();
	 void ShowTextEdit();
  HWND BrowseWindow;
  int UpdatingRow;
  AnsiString TableName,
  ValueColumnName,
  IdColumnName,
  AdditionalCondition;
};
//---------------------------------------------------------------------------
extern PACKAGE TEditValueWindow *EditValueWindow;
//---------------------------------------------------------------------------
#endif
