/*********************************************************/
/*                                                       */
/*          ������ AboutProgWindowUnit                   */
/*  ������ ����, ����������� ���������� � ���������      */
/*                                                       */
/*  Copyright (c) 2005-2006 �������� ���������           */
/*            buls@land.ru                               */
/*                                                       */
/*  �������������: 9.07.2006                             */
/*                                                       */
/*********************************************************/
#pragma once
#ifndef INCLUDED_ABOUTPROGWINDOWUNIT_H
#define INCLUDED_ABOUTPROGWINDOWUNIT_H
#include <Windows.hpp>
#include <Messages.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Graphics.hpp>
#include <ExtCtrls.hpp>
#include <sysutils.hpp>

class TAboutBoxForm : public TForm
{
__published:
    TPanel *Panel1;
    TImage *ProgramIcon;
    TLabel *ProductName;
    TLabel *Copyright;
    TLabel *Comments;
    TBitBtn *OKButton;
  void __fastcall OKButtonClick(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
  void __fastcall FormDestroy(TObject *Sender);
  void __fastcall FormKeyPress(TObject *Sender, char &Key);

private:
  void *FTaskWindowList;
    /* Private declarations */
  
public:
    /* Public declarations */
    __fastcall TAboutBoxForm(TComponent* Owner);
};

extern PACKAGE TAboutBoxForm *AboutBox;
extern "C"
{
void __declspec(dllexport) __stdcall ViewAboutProg(LPSTR lpProductName);
void __declspec(dllexport) __stdcall DestroyAboutWindow();
}

#endif

