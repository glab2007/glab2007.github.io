//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "EditValueUnit.h"
//---------------------------------------------------------------------------
//#pragma package(smart_init)
#pragma resource "*.dfm"
TEditValueWindow *EditValueWindow;
//---------------------------------------------------------------------------
__fastcall TEditValueWindow::TEditValueWindow(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TEditValueWindow::AllKeyPress(TObject *Sender, char &Key)
{
	switch (Key)
	{
		case Char(VK_TAB):
			Key = NULL;
			break;
	}
}
//---------------------------------------------------------------------------
void __fastcall TEditValueWindow::CancelButtonClick(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------

void __fastcall TEditValueWindow::FormCreate(TObject *Sender)
{
	DistanceAfterEditControl = this->ClientHeight - (Value->Top + Value->Height);
}
//---------------------------------------------------------------------------

void TEditValueWindow::ShowDateEdit()
{
	Value->Hide();
	ClientHeight =  DateValue->Top +  DateValue->Height + DistanceAfterEditControl;
	DateValue->Show();
}
//---------------------------------------------------------------------------

void TEditValueWindow::ShowTextEdit()
{
	DateValue->Hide();
	ClientHeight =  Value->Top +  Value->Height + DistanceAfterEditControl;
	Value->Show();
}
//---------------------------------------------------------------------------

