Table Info
Version 1.0

Description

Table Info allows you to get detailed information
on the tables opened within MapInfo (including 
table structures and Metadata records).

This software is freeware which means you can 
do what you like with it except charge money for 
the software. A freeware licence also means that 
you use this software at your own risk.

Please forward any suggestion or problems with 
this software to info@4thbeachsoftware.com.

Have Fun!