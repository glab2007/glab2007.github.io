Append2 is a new verison of the original Append program. 

This new version will append TAB, DBF and MIF files or a mix thereof, but as always, the structures must be identical.  MIF files are imported and WILL OVERWRITE any existing TAB files by the same name.

This version will also append all files in a directory or files spanning multiple directories.

1)  Run Append2.mbx and select Append>Append Tables.
2)  Select the directory where your files are located.
3)  
  a)  Select the file(s) to append. Press Add.
  b)  Select Add All to add all files in the window.
4)  The user can remvoe selected files as well
  a)  Remove single files from the append list via the Remove button
  b)  All from the append list via Remove All
5)  If you want to append to a new file check the box on the right otherwise
the first file in the file list will be appended to. The files in the append list are sorted, sothe first file you add amy not be the first file in the list.

The program is provided as-is with no warranty expressed or implied.
The user is responsible for the use and outcome of said use of this spftware.

Bugs may be reported to jasonb@riskinc.com