# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# substitute_field_names.py
# �������� �������� ����� �� �� �������� ����� �� fields.csv � ������ MIF/TAB
# Author: Maxim Dubinin (sim@gis-lab.info)
# Created: 16:11 26.10.2012
# Updated: 23:46 12.02.2013
# More: http://gis-lab.info/forum/viewtopic.php?f=17&t=11387&p=71031#p71031
# ---------------------------------------------------------------------------

import glob
import sys
import os

def usage():
  '''Show usage synopsis.
  '''
  #python substitute_field_names.py g:\balakovo\oopt\ g:\balakovo\oopt\test\ fields.csv
  print 'Usage: substitute_field_names.py input_folder output_folder fieldsfile'
  sys.exit( 1 )

def find(lst, predicate):
    return (i for i, j in enumerate(lst) if predicate(j)).next()

if __name__ == '__main__':
    args = sys.argv[ 1: ]
    if args is None or len( args ) < 2:
        usage()
    
    foin = args[ 0 ]
    foout = args[ 1 ]
    os.chdir(foin)
    
    #get input and output fields
    infields = []
    outfields = []
    ffn = args[ 2 ]
    ff = open(ffn,"r")
    for row in ff.readlines():
        infields.append(row.split(",")[0].decode("utf-8").encode("cp1251")) 
        outfields.append(row.split(",")[1].decode("utf-8").encode("cp1251").replace("\n","")) 
    
    extensions = ["*.mif","*.tab"]
    files = []
    for extension in extensions:
        files.extend(glob.glob(extension))

    files_count = len(files)
    
    for fn in files:
        fi = open(fn,"r")
        strs = fi.readlines()
        fi.close()
        
        fo = open(foout+"\\"+fn,"w")
        
        i = 0
        for s in strs:
            if i != 0:
                fieldsearch = s.strip(" ").split(" ")[0]
                fieldindex = infields.index(fieldsearch)
                s = s.replace(fieldsearch,outfields[fieldindex])
                i = i + 1
                if i > colsnum: i = 0
            
            if (s.find("Columns") != -1 or s.find("Fields") != -1) and i == 0:
                colsnum = int(s.strip(" ").split(" ")[1])
                i = 1
            fo.write(s)
        
        fo.close()
