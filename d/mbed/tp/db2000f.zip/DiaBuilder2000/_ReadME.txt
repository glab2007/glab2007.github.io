
No install, registry, etc needed.
Just make a shortcut to the exe.

DiaBuilder.chm is a "compiled help" file using Microsoft HTML-Help Workshop

If you can not run the help then you need to goto www.microsoft.com
and get the latest version of Internet Explorer [minimum version of 4.0]
otherwise you need to get an update for HTMLHelp from MicroSoft.

Be sure to put the help file in the same folder as the exe

================================================================

REVISIONS

Version			Enhancements & Fixes

20020208		FIX: MAJOR >> not always saving all controls [BT]
				had to work around problem in 3 party control [not mine]
20020208		FIX: changes filename to lower case after 2clicking in My'Puter
20020207		FIX: problems when 2clicking from My'puter [starts and loads]
				and then opening another project
20001205		FIX: imbeded formating tabs [#9] to indent code lines not reading in as *tab*
					but as text *#9+the line text* [ML]

20001111F		FIX: using 0 or 1 [false/true] for CheckBox>Value results in
				compiler error [have been put in DIM and are invalid]
				FIX: setting RadioGroup>Value to a number [1,2...] would not
				include the Value clause in the dialog
				FIX: CodeEditor>Replace using "entire" text not working correctly
20001015F-1		ENH: added RegSoft "register" to the Splash Screen
				This installed separate application RegSoft.exe
				Does not change Full Version
20001003F-1		FIX: In setting up Command Line Open, created error that you
				can not open an existing project -- ERROR: "File Does Not Exist"
20000928F-1		FIX: "Calling SomeSub" not being added to *.dlg after 1st used
				when you have move than 1 control calling the same function
				ADD: For "Full Version Code Warriors" put /nosplash in the command line
				to hide the splash screen adjusted show time for Full=3secs Demo=8secs
20000923F-1		ADD: Implemented built in "BookMarks" functions of the CodeEditor
				FIX: removed path from MB output file in include 'mapbasic.*' statements
				FIX: when EditText.Value is blank produced errors
				FIX: start application and open project == MI & MB paths are lost
				MOD: swapped position of Test/Preview == you should preview before test

20000921F-1		Help File trying to find images on my hard drive
				M$ FrontPage often fills in full path unexpectedly
				and I faild to check it...FIXED
				When "UserID" is changed in Properties [pressing enter] same
				problem as 20000918f-1 [found in text]...FIXED
				Code Editor not pasting correctly...FIXED
				When Property is showing and new control added with snap turned
				on and final position of control is outside of mouse the Dialog
				is used for properties.  Forced mouse to move to move to Left+1
				and Top+1 to stay inside the contral boundaries.....FIXED
				ADDED "include" statements during compile to the *.mb file for
				MapBasic, Menu, Icons
				REPLACED StringEditor with functions of CodeEditor
20000918f-1		When "UserID" has a name that can be found previously in *.DCL
				same problem as 20000911e-1...FIXED
20000917f-1		Fixed Properties so when changing selections keeps same property
				If new selection property is invalid the "UserID" is active property
20000914f-1		VERSION "F" -- implemented "syntax highlighting code editor"
				****  INI FILE HAS CHANGES  ****
				ADD THE FOLLOWING LINES TO THE BOTTOM OF DiaBuilder.ini
******************************************************************************************
******************************************************************************************
20000911e-1		When "calling" has a name that can be found previously in *.DCL
				then code is not written, to stop duplicate sub statements, 
				EXAMPLE Button1.Calling="bTest_1" 
					    Button2.Calling="bTest" 
					    then 2 found [but different] and not written out...FIXED
20000911e-1		Clicking StatBar does not close it... FIXED
20000910e-1		Misc fine tuning.
				Implemented Ctrl+S for File>Save
20000909e-1		Fixed problems with "paste - Ctrl+V" related to "designer control"
				Changed "PopupMenu" [Combo] to style matching that of MB
09 Sept 2000	Received latest update for "designer control".� 
20000907e-1		Added "UserApp" to INI and Options>Settings
				Path and FileName to your preferred Editor for editing *.USR subs/functions
				NotePad is the default and needs nothing but NotePad [type it in]
				WordPad requires finding the "exe" on your system. [full path / filename]
				MapBasic cries about the extension not being "MB" and requires File Open.
				Syntax highlighting editors really help, most RAD environments do this.
				NOTE: Be sure to save the file as "Plain Text" -- why NotePad is the default
20000906e-1		Locked out ToolBar during "Preview" must unselect to return to Designer mode
20000906e-1		Added "LOCK" to controls for adding multiple controls of same type
				WARNING: Must click selector before clicking on controls in Designer or another 				control will be added and requires deleting ! ! 
20000905e-1		Added "HELP" button to ToolBar, opens this file.
20000904e-1		Added "CODE EDITOR" to allow Custom Sub/Functions
				Not altered by Diabuilder.
Aug 2000		Rewrote using "Designer" control. It handles all the sizing, moving,
				inserting, deleting, etc and saved a lot of time and headaches.
July 2000		First release ver. D as Beta
June 2000		Restarted work Ver. Cin June 2000
Early 1999		Began the first working of this, but had other pressing things 
				[ver.1999xxxxxA-1]